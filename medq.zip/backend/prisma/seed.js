const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding MedQ database...');

  const passwordHash = await bcrypt.hash('password123', 10);

  const user = await prisma.user.upsert({
    where: { email: 'patient@medq.health' },
    update: {},
    create: {
      name: 'Alex Johnson',
      email: 'patient@medq.health',
      passwordHash: passwordHash,
      settings: {
        create: {
          theme: 'SYSTEM',
          notificationEnabled: true,
          soundEnabled: true,
          vibrationEnabled: true,
          timeFormat: '12h',
          demoMode: true,
        },
      },
    },
  });

  const device = await prisma.device.upsert({
    where: { deviceId: 'MEDQ-ESP32-001' },
    update: {},
    create: {
      userId: user.id,
      deviceName: 'MedQ Dispenser Alpha',
      deviceId: 'MEDQ-ESP32-001',
      esp32Ip: '192.168.4.1',
      firmwareVersion: 'v1.2.0-esp32',
      isOnline: true,
      rtcStatus: 'OK (DS3231)',
      oledStatus: 'OK (SSD1306)',
      irStatus: 'OK (Clear)',
      servo1Status: 'OK',
      servo2Status: 'OK',
      buzzerStatus: 'OK',
    },
  });

  const med1 = await prisma.medicine.upsert({
    where: { userId_compartment: { userId: user.id, compartment: 1 } },
    update: {},
    create: {
      userId: user.id,
      name: 'Paracetamol',
      dosage: '500 mg',
      description: 'Pain relief & fever, take with a glass of water',
      compartment: 1,
      enabled: true,
      schedules: {
        create: [
          { time: '08:00 AM', frequency: 'Daily', reminderEnabled: true, enabled: true },
          { time: '08:00 PM', frequency: 'Daily', reminderEnabled: true, enabled: true },
        ],
      },
    },
  });

  const med2 = await prisma.medicine.upsert({
    where: { userId_compartment: { userId: user.id, compartment: 2 } },
    update: {},
    create: {
      userId: user.id,
      name: 'Vitamin C & Zinc',
      dosage: '1000 mg',
      description: 'Immune support, daily morning tablet',
      compartment: 2,
      enabled: true,
      schedules: {
        create: [
          { time: '01:00 PM', frequency: 'Daily', reminderEnabled: true, enabled: true },
        ],
      },
    },
  });

  const med3 = await prisma.medicine.upsert({
    where: { userId_compartment: { userId: user.id, compartment: 3 } },
    update: {},
    create: {
      userId: user.id,
      name: 'Metformin',
      dosage: '500 mg',
      description: 'Blood sugar control, take after meals',
      compartment: 3,
      enabled: true,
      schedules: {
        create: [
          { time: '08:00 PM', frequency: 'Daily', reminderEnabled: true, enabled: true },
        ],
      },
    },
  });

  await prisma.dispensingHistory.createMany({
    data: [
      {
        userId: user.id,
        medicineId: med1.id,
        deviceId: device.id,
        compartment: 1,
        scheduledTime: '08:00 AM',
        status: 'dispensed',
        detectionResult: true,
        mode: 'demo',
      },
      {
        userId: user.id,
        medicineId: med2.id,
        deviceId: device.id,
        compartment: 2,
        scheduledTime: '01:00 PM',
        status: 'dispensed',
        detectionResult: true,
        mode: 'demo',
      },
    ],
  });

  console.log('MedQ database seeding complete!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
