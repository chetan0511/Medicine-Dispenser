# MedQ Backend API

The Node.js + Express + Prisma REST API server for the **MedQ – Smart Medicine Dispenser** system.

## Features
- **JWT Authentication & bcrypt Hashing** (Registration, Login, Password Change, User Profile)
- **PostgreSQL Database with Prisma ORM** (Users, Devices, Medicines, Schedules, Dispensing History, Device Events, Notifications)
- **Medicine & Multi-Schedule CRUD** (Compartments 1 to 4 validation)
- **Automatic & Manual Dispensing Management** with duplicate dose prevention
- **Hardware Integration Dispatch** (communicates with ESP32 via HTTP REST API)
- **Analytics & Adherence Engine** (weekly trends, compliance percentages)
- **Centralized Error Handling & Input Validation**

## Requirements
- Node.js >= 18.x
- PostgreSQL >= 14

## Setup & Running

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure environment:**
   ```bash
   cp .env.example .env
   # Edit .env with your PostgreSQL credentials and JWT secret
   ```

3. **Generate Prisma Client & Run Migrations:**
   ```bash
   npx prisma generate
   npx prisma migrate dev --name init
   ```

4. **Seed database with default test data:**
   ```bash
   npm run seed
   ```

5. **Start server:**
   ```bash
   # Development mode with nodemon:
   npm run dev

   # Production mode:
   npm start
   ```

The server starts on `http://localhost:5000`.

## API Endpoints

### Authentication
- `POST /api/auth/register` - Create new user account
- `POST /api/auth/login` - Sign in and get JWT token
- `POST /api/auth/logout` - Invalidate session
- `GET /api/auth/me` - Get current user profile
- `PUT /api/auth/profile` - Update profile name and email
- `PUT /api/auth/password` - Change password

### Medicines
- `GET /api/medicines` - List all user medicines with schedules
- `POST /api/medicines` - Add medicine to tray (compartment 1-4)
- `GET /api/medicines/:id` - Get medicine details
- `PUT /api/medicines/:id` - Update medicine & schedules
- `DELETE /api/medicines/:id` - Delete medicine from tray

### Schedules
- `GET /api/schedules` - List all schedules
- `POST /api/schedules` - Create a schedule
- `PUT /api/schedules/:id` - Update schedule time/frequency
- `DELETE /api/schedules/:id` - Delete schedule

### Dispensing
- `POST /api/dispense` - Trigger medicine dispensing (demo mode simulation or real ESP32 command)
- `GET /api/dispense/history` - List dispensing history with filters (`filter=TODAY|WEEK|MONTH|ALL`, `search=name`)
- `GET /api/dispense/:id` - Get specific dispensing attempt details

### Hardware Devices
- `GET /api/devices` - List registered MedQ devices
- `POST /api/devices` - Register new ESP32 device
- `GET /api/devices/:id/status` - Query real-time subsystem statuses
- `POST /api/devices/:id/test` - Trigger component diagnostic test

### Analytics
- `GET /api/analytics/summary` - Adherence percentage, completed/missed/failed counts
- `GET /api/analytics/weekly` - Weekly dose compliance trends
