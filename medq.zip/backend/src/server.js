const app = require('./app');
const config = require('./config');

const PORT = config.port;

app.listen(PORT, () => {
  console.log(`========================================`);
  console.log(` MedQ - Smart Medicine Dispenser Backend`);
  console.log(` Server running on http://localhost:${PORT}`);
  console.log(` Environment: ${config.nodeEnv}`);
  console.log(`========================================`);
});
