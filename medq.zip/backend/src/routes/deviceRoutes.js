const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const deviceController = require('../controllers/deviceController');
const authMiddleware = require('../middleware/auth');
const validate = require('../middleware/validator');

router.use(authMiddleware);

router.get('/', deviceController.getAll);
router.get('/:id', deviceController.getById);

router.post(
  '/',
  [body('deviceId').notEmpty().withMessage('deviceId is required'), validate],
  deviceController.register
);

router.put('/:id', deviceController.update);
router.delete('/:id', deviceController.delete);
router.get('/:id/status', deviceController.getStatus);
router.post('/:id/test', deviceController.testDevice);

module.exports = router;
