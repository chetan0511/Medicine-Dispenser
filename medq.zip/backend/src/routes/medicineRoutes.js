const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const medicineController = require('../controllers/medicineController');
const authMiddleware = require('../middleware/auth');
const validate = require('../middleware/validator');

router.use(authMiddleware);

router.get('/', medicineController.getAll);
router.get('/:id', medicineController.getById);

router.post(
  '/',
  [
    body('name').trim().notEmpty().withMessage('Medicine name is required'),
    body('dosage').trim().notEmpty().withMessage('Dosage is required'),
    body('compartment')
      .isInt({ min: 1, max: 4 })
      .withMessage('Compartment must be an integer between 1 and 4'),
    validate,
  ],
  medicineController.create
);

router.put('/:id', medicineController.update);
router.delete('/:id', medicineController.delete);

module.exports = router;
