const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const dispenseController = require('../controllers/dispenseController');
const authMiddleware = require('../middleware/auth');
const validate = require('../middleware/validator');

router.use(authMiddleware);

router.post(
  '/',
  [
    body('compartment')
      .isInt({ min: 1, max: 4 })
      .withMessage('Compartment must be 1, 2, 3, or 4'),
    validate,
  ],
  dispenseController.dispenseNow
);

router.get('/history', dispenseController.getHistory);
router.get('/:id', dispenseController.getHistoryById);

module.exports = router;
