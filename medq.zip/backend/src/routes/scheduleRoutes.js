const express = require('express');
const { body } = require('express-validator');
const router = express.Router();
const scheduleController = require('../controllers/scheduleController');
const authMiddleware = require('../middleware/auth');
const validate = require('../middleware/validator');

router.use(authMiddleware);

router.get('/', scheduleController.getAll);

router.post(
  '/',
  [
    body('medicineId').notEmpty().withMessage('medicineId is required'),
    body('time').notEmpty().withMessage('Schedule time is required'),
    validate,
  ],
  scheduleController.create
);

router.put('/:id', scheduleController.update);
router.delete('/:id', scheduleController.delete);

module.exports = router;
