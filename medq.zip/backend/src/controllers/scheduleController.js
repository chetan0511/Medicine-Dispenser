const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.getAll = async (req, res, next) => {
  try {
    const schedules = await prisma.medicineSchedule.findMany({
      where: { medicine: { userId: req.user.userId } },
      include: { medicine: true },
      orderBy: { time: 'asc' },
    });
    res.status(200).json({ success: true, data: schedules });
  } catch (err) {
    next(err);
  }
};

exports.create = async (req, res, next) => {
  try {
    const { medicineId, time, frequency, selectedDays, reminderEnabled, enabled } = req.body;

    const med = await prisma.medicine.findFirst({
      where: { id: medicineId, userId: req.user.userId },
    });
    if (!med) return res.status(404).json({ success: false, message: 'Medicine not found' });

    const schedule = await prisma.medicineSchedule.create({
      data: {
        medicineId,
        time,
        frequency: frequency || 'Daily',
        selectedDays: selectedDays || 'All',
        reminderEnabled: reminderEnabled ?? true,
        enabled: enabled ?? true,
      },
    });

    res.status(201).json({ success: true, message: 'Schedule created', data: schedule });
  } catch (err) {
    next(err);
  }
};

exports.update = async (req, res, next) => {
  try {
    const { time, frequency, selectedDays, reminderEnabled, enabled } = req.body;
    const sch = await prisma.medicineSchedule.findFirst({
      where: { id: req.params.id, medicine: { userId: req.user.userId } },
    });
    if (!sch) return res.status(404).json({ success: false, message: 'Schedule not found' });

    const updated = await prisma.medicineSchedule.update({
      where: { id: sch.id },
      data: {
        ...(time && { time }),
        ...(frequency && { frequency }),
        ...(selectedDays && { selectedDays }),
        ...(reminderEnabled !== undefined && { reminderEnabled }),
        ...(enabled !== undefined && { enabled }),
      },
    });

    res.status(200).json({ success: true, message: 'Schedule updated', data: updated });
  } catch (err) {
    next(err);
  }
};

exports.delete = async (req, res, next) => {
  try {
    const sch = await prisma.medicineSchedule.findFirst({
      where: { id: req.params.id, medicine: { userId: req.user.userId } },
    });
    if (!sch) return res.status(404).json({ success: false, message: 'Schedule not found' });

    await prisma.medicineSchedule.delete({ where: { id: sch.id } });
    res.status(200).json({ success: true, message: 'Schedule deleted' });
  } catch (err) {
    next(err);
  }
};
