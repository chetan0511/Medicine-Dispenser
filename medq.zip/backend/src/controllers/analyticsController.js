const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.getSummary = async (req, res, next) => {
  try {
    const userId = req.user.userId;

    const total = await prisma.dispensingHistory.count({ where: { userId } });
    const completed = await prisma.dispensingHistory.count({
      where: { userId, status: { in: ['dispensed', 'manual'] } },
    });
    const missed = await prisma.dispensingHistory.count({
      where: { userId, status: 'missed' },
    });
    const failed = await prisma.dispensingHistory.count({
      where: { userId, status: 'failed' },
    });
    const notDetected = await prisma.dispensingHistory.count({
      where: { userId, status: 'not_detected' },
    });

    const adherence = total > 0 ? Math.round((completed / total) * 100) : 100;

    res.status(200).json({
      success: true,
      data: {
        totalDoses: total,
        completedDoses: completed,
        missedDoses: missed,
        failedDoses: failed,
        notDetectedDoses: notDetected,
        adherencePercentage: adherence,
      },
    });
  } catch (err) {
    next(err);
  }
};

exports.getWeekly = async (req, res, next) => {
  try {
    const userId = req.user.userId;
    const sevenDaysAgo = new Date(Date.now() - 7 * 86400000);

    const weeklyHistories = await prisma.dispensingHistory.findMany({
      where: { userId, createdAt: { gte: sevenDaysAgo } },
      select: { createdAt: true, status: true, compartment: true },
    });

    res.status(200).json({
      success: true,
      data: {
        count: weeklyHistories.length,
        events: weeklyHistories,
      },
    });
  } catch (err) {
    next(err);
  }
};
