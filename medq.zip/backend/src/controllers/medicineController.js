const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.getAll = async (req, res, next) => {
  try {
    const medicines = await prisma.medicine.findMany({
      where: { userId: req.user.userId },
      include: { schedules: true },
      orderBy: { compartment: 'asc' },
    });
    res.status(200).json({ success: true, data: medicines });
  } catch (err) {
    next(err);
  }
};

exports.getById = async (req, res, next) => {
  try {
    const medicine = await prisma.medicine.findFirst({
      where: { id: req.params.id, userId: req.user.userId },
      include: { schedules: true },
    });
    if (!medicine) return res.status(404).json({ success: false, message: 'Medicine not found' });
    res.status(200).json({ success: true, data: medicine });
  } catch (err) {
    next(err);
  }
};

exports.create = async (req, res, next) => {
  try {
    const { name, dosage, description, compartment, enabled, schedules } = req.body;

    const existingCompartment = await prisma.medicine.findFirst({
      where: { userId: req.user.userId, compartment: parseInt(compartment) },
    });
    if (existingCompartment) {
      return res.status(409).json({
        success: false,
        message: `Compartment ${compartment} is already occupied by ${existingCompartment.name}`,
      });
    }

    const medicine = await prisma.medicine.create({
      data: {
        userId: req.user.userId,
        name,
        dosage,
        description,
        compartment: parseInt(compartment),
        enabled: enabled ?? true,
        ...(Array.isArray(schedules) && schedules.length > 0 && {
          schedules: {
            create: schedules.map((s) => ({
              time: typeof s === 'string' ? s : s.time,
              frequency: s.frequency || 'Daily',
              reminderEnabled: s.reminderEnabled ?? true,
              enabled: s.enabled ?? true,
            })),
          },
        }),
      },
      include: { schedules: true },
    });

    res.status(201).json({
      success: true,
      message: 'Medicine added to tray successfully',
      data: medicine,
    });
  } catch (err) {
    next(err);
  }
};

exports.update = async (req, res, next) => {
  try {
    const { name, dosage, description, compartment, enabled, schedules } = req.body;

    const med = await prisma.medicine.findFirst({
      where: { id: req.params.id, userId: req.user.userId },
    });
    if (!med) return res.status(404).json({ success: false, message: 'Medicine not found' });

    if (compartment && parseInt(compartment) !== med.compartment) {
      const occupied = await prisma.medicine.findFirst({
        where: { userId: req.user.userId, compartment: parseInt(compartment), NOT: { id: med.id } },
      });
      if (occupied) {
        return res.status(409).json({
          success: false,
          message: `Compartment ${compartment} is already assigned to ${occupied.name}`,
        });
      }
    }

    const updated = await prisma.$transaction(async (tx) => {
      if (Array.isArray(schedules)) {
        await tx.medicineSchedule.deleteMany({ where: { medicineId: med.id } });
        if (schedules.length > 0) {
          await tx.medicineSchedule.createMany({
            data: schedules.map((s) => ({
              medicineId: med.id,
              time: typeof s === 'string' ? s : s.time,
              frequency: s.frequency || 'Daily',
              reminderEnabled: s.reminderEnabled ?? true,
              enabled: s.enabled ?? true,
            })),
          });
        }
      }

      return tx.medicine.update({
        where: { id: med.id },
        data: {
          ...(name && { name }),
          ...(dosage && { dosage }),
          ...(description !== undefined && { description }),
          ...(compartment && { compartment: parseInt(compartment) }),
          ...(enabled !== undefined && { enabled }),
        },
        include: { schedules: true },
      });
    });

    res.status(200).json({ success: true, message: 'Medicine updated', data: updated });
  } catch (err) {
    next(err);
  }
};

exports.delete = async (req, res, next) => {
  try {
    const med = await prisma.medicine.findFirst({
      where: { id: req.params.id, userId: req.user.userId },
    });
    if (!med) return res.status(404).json({ success: false, message: 'Medicine not found' });

    await prisma.medicine.delete({ where: { id: med.id } });
    res.status(200).json({ success: true, message: 'Medicine removed from tray' });
  } catch (err) {
    next(err);
  }
};
