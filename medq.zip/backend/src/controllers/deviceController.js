const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.getAll = async (req, res, next) => {
  try {
    const devices = await prisma.device.findMany({
      where: { userId: req.user.userId },
      include: { events: { take: 10, orderBy: { createdAt: 'desc' } } },
    });
    res.status(200).json({ success: true, data: devices });
  } catch (err) {
    next(err);
  }
};

exports.getById = async (req, res, next) => {
  try {
    const device = await prisma.device.findFirst({
      where: { id: req.params.id, userId: req.user.userId },
      include: { events: { take: 25, orderBy: { createdAt: 'desc' } } },
    });
    if (!device) return res.status(404).json({ success: false, message: 'Device not found' });
    res.status(200).json({ success: true, data: device });
  } catch (err) {
    next(err);
  }
};

exports.register = async (req, res, next) => {
  try {
    const { deviceName, deviceId, esp32Ip } = req.body;
    const device = await prisma.device.create({
      data: {
        userId: req.user.userId,
        deviceName: deviceName || 'MedQ Dispenser',
        deviceId,
        esp32Ip: esp32Ip || '192.168.4.1',
        isOnline: true,
      },
    });
    res.status(201).json({ success: true, message: 'Device registered successfully', data: device });
  } catch (err) {
    next(err);
  }
};

exports.update = async (req, res, next) => {
  try {
    const { deviceName, esp32Ip, firmwareVersion } = req.body;
    const updated = await prisma.device.update({
      where: { id: req.params.id },
      data: {
        ...(deviceName && { deviceName }),
        ...(esp32Ip && { esp32Ip }),
        ...(firmwareVersion && { firmwareVersion }),
      },
    });
    res.status(200).json({ success: true, message: 'Device updated', data: updated });
  } catch (err) {
    next(err);
  }
};

exports.delete = async (req, res, next) => {
  try {
    await prisma.device.delete({ where: { id: req.params.id } });
    res.status(200).json({ success: true, message: 'Device deleted' });
  } catch (err) {
    next(err);
  }
};

exports.getStatus = async (req, res, next) => {
  try {
    const device = await prisma.device.findFirst({ where: { id: req.params.id, userId: req.user.userId } });
    if (!device) return res.status(404).json({ success: false, message: 'Device not found' });

    res.status(200).json({
      success: true,
      data: {
        deviceId: device.deviceId,
        esp32Ip: device.esp32Ip,
        isOnline: device.isOnline,
        lastSeen: device.lastSeen,
        subsystems: {
          rtc: device.rtcStatus,
          oled: device.oledStatus,
          ir: device.irStatus,
          servo1: device.servo1Status,
          servo2: device.servo2Status,
          buzzer: device.buzzerStatus,
        },
      },
    });
  } catch (err) {
    next(err);
  }
};

exports.testDevice = async (req, res, next) => {
  try {
    const { component, action } = req.body;
    const device = await prisma.device.findFirst({ where: { id: req.params.id, userId: req.user.userId } });
    if (!device) return res.status(404).json({ success: false, message: 'Device not found' });

    await prisma.deviceEvent.create({
      data: {
        deviceId: device.id,
        eventType: `${component?.toUpperCase()}_TEST`,
        description: `Manual diagnostic command triggered: ${component} -> ${action}`,
      },
    });

    res.status(200).json({
      success: true,
      message: `Diagnostic command sent to ${component} (${action})`,
    });
  } catch (err) {
    next(err);
  }
};
