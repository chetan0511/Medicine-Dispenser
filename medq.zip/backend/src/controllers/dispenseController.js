const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.dispenseNow = async (req, res, next) => {
  try {
    const { compartment, medicineId, idempotencyKey } = req.body;
    const userId = req.user.userId;

    const parsedCompartment = parseInt(compartment);
    if (!parsedCompartment || parsedCompartment < 1 || parsedCompartment > 4) {
      return res.status(400).json({ success: false, message: 'Invalid compartment number (1-4 required)' });
    }

    // Check medicine details
    let medicine = null;
    if (medicineId) {
      medicine = await prisma.medicine.findFirst({ where: { id: medicineId, userId } });
    } else {
      medicine = await prisma.medicine.findFirst({ where: { compartment: parsedCompartment, userId } });
    }

    const medName = medicine ? medicine.name : `Compartment ${parsedCompartment}`;
    const dosage = medicine ? medicine.dosage : 'Standard Dose';

    // Duplicate dispensing prevention: check if a dispense occurred in the last 15 seconds for this compartment
    const recent = await prisma.dispensingHistory.findFirst({
      where: {
        userId,
        compartment: parsedCompartment,
        createdAt: { gte: new Date(Date.now() - 15000) },
      },
    });

    if (recent) {
      return res.status(429).json({
        success: false,
        message: 'Duplicate dispensing prevention: A dose was just dispensed for this compartment. Please wait.',
      });
    }

    // Check device settings
    const device = await prisma.device.findFirst({ where: { userId } });
    const settings = await prisma.appSettings.findUnique({ where: { userId } });
    const isDemo = settings ? settings.demoMode : true;

    if (isDemo) {
      // Demo Mode: simulate successful workflow
      const history = await prisma.dispensingHistory.create({
        data: {
          userId,
          medicineId: medicine?.id,
          deviceId: device?.id,
          compartment: parsedCompartment,
          scheduledTime: 'Manual Request',
          status: 'dispensed',
          detectionResult: true,
          mode: 'demo',
        },
      });

      if (device) {
        await prisma.deviceEvent.create({
          data: {
            deviceId: device.id,
            eventType: 'DISPENSE_SUCCESS',
            description: `Demo dispensed ${medName} (${dosage}) from Compartment ${parsedCompartment}`,
          },
        });
      }

      return res.status(200).json({
        success: true,
        message: `Successfully dispensed ${medName} from Compartment ${parsedCompartment} (Demo Mode).`,
        data: history,
      });
    }

    // Real Hardware Mode: Dispatch HTTP command to ESP32 IP
    if (!device || !device.esp32Ip) {
      return res.status(400).json({
        success: false,
        message: 'No active ESP32 device configured. Switch to Demo Mode or configure ESP32 IP.',
      });
    }

    try {
      // In production Node environment: call fetch(`http://${device.esp32Ip}/api/dispense`, ...)
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000);

      const esp32Res = await fetch(`http://${device.esp32Ip}/api/dispense`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          compartment: parsedCompartment,
          medicine: medName,
          dosage,
        }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      const espData = await esp32Res.json();
      const detected = Boolean(espData.detected);

      const history = await prisma.dispensingHistory.create({
        data: {
          userId,
          medicineId: medicine?.id,
          deviceId: device.id,
          compartment: parsedCompartment,
          scheduledTime: 'Manual Request',
          status: detected ? 'dispensed' : 'not_detected',
          detectionResult: detected,
          mode: 'real',
          errorMessage: detected ? null : 'IR sensor did not detect pill falling',
        },
      });

      return res.status(200).json({
        success: detected,
        message: detected
          ? `Medicine dispensed and confirmed by IR optical sensor.`
          : `Dispenser opened, but pill was not detected by IR sensor.`,
        data: history,
      });
    } catch (netErr) {
      await prisma.dispensingHistory.create({
        data: {
          userId,
          medicineId: medicine?.id,
          deviceId: device.id,
          compartment: parsedCompartment,
          scheduledTime: 'Manual Request',
          status: 'failed',
          detectionResult: false,
          mode: 'real',
          errorMessage: `ESP32 connection failed: ${netErr.message}`,
        },
      });

      return res.status(502).json({
        success: false,
        message: `Cannot reach ESP32 at ${device.esp32Ip}. Hardware is offline or unreachable.`,
      });
    }
  } catch (err) {
    next(err);
  }
};

exports.getHistory = async (req, res, next) => {
  try {
    const { filter, search } = req.query;
    const userId = req.user.userId;

    let timeFilter = {};
    const now = Date.now();
    if (filter === 'TODAY') {
      timeFilter = { createdAt: { gte: new Date(now - 86400000) } };
    } else if (filter === 'WEEK') {
      timeFilter = { createdAt: { gte: new Date(now - 7 * 86400000) } };
    } else if (filter === 'MONTH') {
      timeFilter = { createdAt: { gte: new Date(now - 30 * 86400000) } };
    }

    const histories = await prisma.dispensingHistory.findMany({
      where: {
        userId,
        ...timeFilter,
        ...(search && {
          medicine: { name: { contains: search, mode: 'insensitive' } },
        }),
      },
      include: { medicine: true },
      orderBy: { createdAt: 'desc' },
    });

    res.status(200).json({ success: true, data: histories });
  } catch (err) {
    next(err);
  }
};

exports.getHistoryById = async (req, res, next) => {
  try {
    const history = await prisma.dispensingHistory.findFirst({
      where: { id: req.params.id, userId: req.user.userId },
      include: { medicine: true, device: true },
    });
    if (!history) return res.status(404).json({ success: false, message: 'Record not found' });
    res.status(200).json({ success: true, data: history });
  } catch (err) {
    next(err);
  }
};
