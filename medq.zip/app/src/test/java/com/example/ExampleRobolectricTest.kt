package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.DispensingHistoryEntity
import com.example.data.model.DispensingState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("MedQ", appName)
  }

  @Test
  fun `verify dispensing states order and naming`() {
    assertEquals("Ready", DispensingState.IDLE.label)
    assertEquals("Buzzer Alerting Patient", DispensingState.ALERTING.label)
    assertEquals("IR Beam Confirmed Pill Drop", DispensingState.MEDICINE_DETECTED.label)
    assertEquals("Dispense Completed Successfully", DispensingState.COMPLETED.label)
  }
}
