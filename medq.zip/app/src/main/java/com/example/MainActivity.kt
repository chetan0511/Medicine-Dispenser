package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.AppSettingsEntity
import com.example.data.model.HardwareStatus
import com.example.ui.components.DispensingProgressModal
import com.example.ui.components.MedQTopBar
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MedQViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    private val viewModel: MedQViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settings by viewModel.settings.collectAsState()
            MyApplicationTheme(themeMode = settings?.themeMode ?: "DARK") {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: MedQViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val hardwareStatus by viewModel.hardwareStatus.collectAsState()

    val isDispensingModalVisible by viewModel.isDispensingModalVisible.collectAsState()
    val activeDispensingState by viewModel.activeDispensingState.collectAsState()
    val dispensingStatusMessage by viewModel.dispensingStatusMessage.collectAsState()
    val currentDispensingTarget by viewModel.currentDispensingTarget.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    var selectedCompartmentForAdd by remember { mutableStateOf<Int?>(null) }

    // Listen for transient notifications
    LaunchedEffect(Unit) {
        viewModel.uiNotification.collectLatest { notif ->
            snackbarHostState.showSnackbar(
                message = "${notif.title}: ${notif.message}",
                duration = SnackbarDuration.Short
            )
        }
    }

    if (currentScreen == AppScreen.SPLASH) {
        SplashScreen(
            onSplashFinished = {
                viewModel.navigateTo(AppScreen.HOME)
            }
        )
        return
    }

    if (currentScreen == AppScreen.AUTH) {
        AuthScreen(
            viewModel = viewModel,
            onAuthSuccess = {
                viewModel.navigateTo(AppScreen.HOME)
            }
        )
        return
    }

    // Main App with Scaffold and Bottom Navigation
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            MedQTopBar(
                title = when (currentScreen) {
                    AppScreen.HOME -> "MedQ"
                    AppScreen.MEDICINES -> "Medicines"
                    AppScreen.CONTROL -> "Hardware"
                    AppScreen.HISTORY -> "History"
                    AppScreen.SETTINGS -> "Settings"
                    else -> "MedQ"
                },
                isDemoMode = settings?.isDemoMode ?: true,
                hardwareStatus = hardwareStatus,
                onModeClick = {
                    viewModel.toggleDemoMode(!(settings?.isDemoMode ?: true))
                }
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = currentScreen == AppScreen.HOME,
                    onClick = { viewModel.navigateTo(AppScreen.HOME) },
                    icon = { Icon(if (currentScreen == AppScreen.HOME) Icons.Filled.Home else Icons.Outlined.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    modifier = Modifier.testTag("nav_item_home")
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.MEDICINES,
                    onClick = { viewModel.navigateTo(AppScreen.MEDICINES) },
                    icon = { Icon(if (currentScreen == AppScreen.MEDICINES) Icons.Filled.Medication else Icons.Outlined.Medication, contentDescription = "Medicines") },
                    label = { Text("Medicines") },
                    modifier = Modifier.testTag("nav_item_medicines")
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.CONTROL,
                    onClick = { viewModel.navigateTo(AppScreen.CONTROL) },
                    icon = { Icon(if (currentScreen == AppScreen.CONTROL) Icons.Filled.Tune else Icons.Outlined.Tune, contentDescription = "Control") },
                    label = { Text("Control") },
                    modifier = Modifier.testTag("nav_item_control")
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.HISTORY,
                    onClick = { viewModel.navigateTo(AppScreen.HISTORY) },
                    icon = { Icon(if (currentScreen == AppScreen.HISTORY) Icons.Filled.History else Icons.Outlined.History, contentDescription = "History") },
                    label = { Text("History") },
                    modifier = Modifier.testTag("nav_item_history")
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.SETTINGS,
                    onClick = { viewModel.navigateTo(AppScreen.SETTINGS) },
                    icon = { Icon(if (currentScreen == AppScreen.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") },
                    modifier = Modifier.testTag("nav_item_settings")
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.HOME -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onAddMedicineForCompartment = { compNum ->
                            selectedCompartmentForAdd = compNum
                            viewModel.navigateTo(AppScreen.MEDICINES)
                        }
                    )
                }
                AppScreen.MEDICINES -> {
                    BackHandler { viewModel.navigateTo(AppScreen.HOME) }
                    MedicinesScreen(
                        viewModel = viewModel,
                        initialTargetCompartment = selectedCompartmentForAdd,
                        onResetInitialCompartment = { selectedCompartmentForAdd = null }
                    )
                }
                AppScreen.CONTROL -> {
                    BackHandler { viewModel.navigateTo(AppScreen.HOME) }
                    ControlScreen(viewModel = viewModel)
                }
                AppScreen.HISTORY -> {
                    BackHandler { viewModel.navigateTo(AppScreen.HOME) }
                    HistoryScreen(viewModel = viewModel)
                }
                AppScreen.SETTINGS -> {
                    BackHandler { viewModel.navigateTo(AppScreen.HOME) }
                    SettingsScreen(
                        viewModel = viewModel,
                        onLogout = { viewModel.navigateTo(AppScreen.AUTH) }
                    )
                }
                else -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onAddMedicineForCompartment = {}
                    )
                }
            }
        }
    }

    // Real-time Dispensing State Machine Interactive Modal
    DispensingProgressModal(
        visible = isDispensingModalVisible,
        target = currentDispensingTarget,
        state = activeDispensingState,
        statusMessage = dispensingStatusMessage,
        onDismiss = { viewModel.dismissDispensingModal() }
    )
}
