package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.MedicineEntity
import com.example.ui.viewmodel.MedQViewModel

@Composable
fun MedicinesScreen(
    viewModel: MedQViewModel,
    initialTargetCompartment: Int? = null,
    onResetInitialCompartment: () -> Unit = {}
) {
    val medicines by viewModel.medicines.collectAsState()
    val schedules by viewModel.schedules.collectAsState()

    var showEditDialog by remember { mutableStateOf(false) }
    var editingMedicine by remember { mutableStateOf<MedicineEntity?>(null) }
    var selectedCompartmentForAdd by remember { mutableIntStateOf(1) }
    var medicineToDelete by remember { mutableStateOf<MedicineEntity?>(null) }

    // If navigated with initialTargetCompartment, open add dialog immediately
    LaunchedEffect(initialTargetCompartment) {
        if (initialTargetCompartment != null) {
            val existing = medicines.firstOrNull { it.compartment == initialTargetCompartment }
            editingMedicine = existing
            selectedCompartmentForAdd = initialTargetCompartment
            showEditDialog = true
            onResetInitialCompartment()
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingMedicine = null
                    selectedCompartmentForAdd = 1
                    showEditDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.testTag("add_medicine_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Medicine")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .testTag("medicines_screen")
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Medication Schedules & Trays",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Configure 4 dispenser bays with custom dosages and reminder times",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            if (medicines.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 64.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Outlined.Medication,
                            contentDescription = "Empty",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No medicines added yet.",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Tap the + button below to add your first medicine.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(medicines, key = { it.id }) { med ->
                        val medSchedules = schedules.filter { it.medicineId == med.id }
                        MedicineListItem(
                            medicine = med,
                            schedules = medSchedules.map { it.time },
                            onToggleEnabled = { enabled ->
                                viewModel.toggleMedicine(med.id, enabled)
                            },
                            onEdit = {
                                editingMedicine = med
                                selectedCompartmentForAdd = med.compartment
                                showEditDialog = true
                            },
                            onDelete = {
                                medicineToDelete = med
                            },
                            onDispense = {
                                viewModel.startDispense(
                                    compartment = med.compartment,
                                    medicineName = med.name,
                                    dosage = med.dosage,
                                    medicineId = med.id
                                )
                            }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Medicine Dialog
    if (showEditDialog) {
        MedicineFormDialog(
            medicine = editingMedicine,
            initialCompartment = selectedCompartmentForAdd,
            onDismiss = { showEditDialog = false },
            onSave = { name, dosage, desc, compartment, enabled, schTimes ->
                viewModel.saveMedicine(
                    id = editingMedicine?.id,
                    name = name,
                    dosage = dosage,
                    desc = desc,
                    compartment = compartment,
                    enabled = enabled,
                    schedules = schTimes,
                    onSuccess = { showEditDialog = false }
                )
            }
        )
    }

    // Delete Confirmation Dialog
    if (medicineToDelete != null) {
        AlertDialog(
            onDismissRequest = { medicineToDelete = null },
            title = { Text("Delete Medicine") },
            text = { Text("Are you sure you want to remove ${medicineToDelete?.name} from Compartment ${medicineToDelete?.compartment}? All associated scheduled alarms will be cleared.") },
            confirmButton = {
                Button(
                    onClick = {
                        medicineToDelete?.id?.let { viewModel.deleteMedicine(it) }
                        medicineToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_med_btn")
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { medicineToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun MedicineListItem(
    medicine: MedicineEntity,
    schedules: List<String>,
    onToggleEnabled: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onDispense: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("medicine_item_${medicine.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "Compartment ${medicine.compartment}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Switch(
                    checked = medicine.enabled,
                    onCheckedChange = onToggleEnabled,
                    modifier = Modifier.testTag("toggle_med_${medicine.id}")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = medicine.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Dosage: ${medicine.dosage}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (medicine.description.isNotBlank()) {
                Text(
                    text = medicine.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Schedules chips
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Outlined.Schedule,
                    contentDescription = "Schedule",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                if (schedules.isEmpty()) {
                    Text(
                        text = "No times set",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    schedules.forEach { time ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Text(
                                text = time,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onEdit,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Outlined.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Edit")
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        Icons.Outlined.Delete,
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.error
                    )
                }

                Button(
                    onClick = onDispense,
                    enabled = medicine.enabled,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1.2f)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Dispense", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Dispense")
                }
            }
        }
    }
}

@Composable
fun MedicineFormDialog(
    medicine: MedicineEntity?,
    initialCompartment: Int,
    onDismiss: () -> Unit,
    onSave: (name: String, dosage: String, desc: String, compartment: Int, enabled: Boolean, schedules: List<String>) -> Unit
) {
    var name by remember { mutableStateOf(medicine?.name ?: "") }
    var dosage by remember { mutableStateOf(medicine?.dosage ?: "") }
    var description by remember { mutableStateOf(medicine?.description ?: "") }
    var compartment by remember { mutableIntStateOf(medicine?.compartment ?: initialCompartment) }
    var enabled by remember { mutableStateOf(medicine?.enabled ?: true) }

    // Schedules (up to 3 times per day)
    var time1 by remember { mutableStateOf("08:00 AM") }
    var time2 by remember { mutableStateOf("02:00 PM") }
    var time3 by remember { mutableStateOf("08:00 PM") }
    var enableTime2 by remember { mutableStateOf(false) }
    var enableTime3 by remember { mutableStateOf(false) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (medicine == null) "Add Medicine" else "Edit Medicine") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                if (errorMessage != null) {
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Medicine Name *") },
                    placeholder = { Text("e.g. Paracetamol") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("med_form_name_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = dosage,
                    onValueChange = { dosage = it },
                    label = { Text("Dosage *") },
                    placeholder = { Text("e.g. 500 mg, 1 tablet") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("med_form_dosage_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Instructions / Notes") },
                    placeholder = { Text("e.g. Take with water after meals") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Assign Compartment (Tray Bay)",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    (1..4).forEach { compNum ->
                        FilterChip(
                            selected = compartment == compNum,
                            onClick = { compartment = compNum },
                            label = { Text("Bay $compNum") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chip_bay_$compNum")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Daily Dispense Schedules",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = time1,
                    onValueChange = { time1 = it },
                    label = { Text("Schedule 1 (e.g. 08:00 AM)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = enableTime2, onCheckedChange = { enableTime2 = it })
                    Text("Add 2nd Daily Dose")
                }
                if (enableTime2) {
                    OutlinedTextField(
                        value = time2,
                        onValueChange = { time2 = it },
                        label = { Text("Schedule 2 (e.g. 02:00 PM)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = enableTime3, onCheckedChange = { enableTime3 = it })
                    Text("Add 3rd Daily Dose")
                }
                if (enableTime3) {
                    OutlinedTextField(
                        value = time3,
                        onValueChange = { time3 = it },
                        label = { Text("Schedule 3 (e.g. 08:00 PM)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        errorMessage = "Medicine name is required."
                        return@Button
                    }
                    if (dosage.isBlank()) {
                        errorMessage = "Dosage is required."
                        return@Button
                    }
                    val schList = mutableListOf(time1)
                    if (enableTime2 && time2.isNotBlank()) schList.add(time2)
                    if (enableTime3 && time3.isNotBlank()) schList.add(time3)

                    onSave(name, dosage, description, compartment, enabled, schList)
                },
                modifier = Modifier.testTag("save_medicine_btn")
            ) {
                Text("Save Medicine")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
