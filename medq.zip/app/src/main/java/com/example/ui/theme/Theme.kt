package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = MedQPrimaryTealDark,
    onPrimary = Color(0xFF042F2E),
    primaryContainer = MedQPrimaryContainerDark,
    onPrimaryContainer = MedQOnPrimaryContainerDark,
    secondary = MedQSecondary,
    onSecondary = Color(0xFF03283E),
    secondaryContainer = Color(0xFF0C3852),
    onSecondaryContainer = Color(0xFFBAE6FD),
    tertiary = StatusWarning,
    background = MedQDarkBg,
    onBackground = Color(0xFFF1F5F9),
    surface = MedQDarkSurface,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = MedQDarkCard,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = MedQDarkBorder,
    outlineVariant = MedQDarkBorder.copy(alpha = 0.7f),
    error = StatusError,
    onError = Color.White,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = MedQPrimaryTeal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCCFBF1),
    onPrimaryContainer = Color(0xFF115E59),
    secondary = MedQPrimaryBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF0369A1),
    tertiary = StatusWarning,
    background = MedQLightBg,
    onBackground = Color(0xFF0F172A),
    surface = MedQLightSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = MedQLightCard,
    onSurfaceVariant = Color(0xFF475569),
    outline = MedQLightBorder,
    outlineVariant = MedQLightBorder,
    error = StatusError,
    onError = Color.White,
  )

@Composable
fun MyApplicationTheme(
  themeMode: String = "SYSTEM", // "LIGHT", "DARK", "SYSTEM"
  content: @Composable () -> Unit,
) {
  val isSystemDark = isSystemInDarkTheme()
  val useDark = when (themeMode) {
    "DARK" -> true
    "LIGHT" -> false
    else -> isSystemDark
  }

  val colorScheme = if (useDark) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
