package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CompartmentInfo
import com.example.data.model.DispensingState
import com.example.data.model.HardwareStatus
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedQTopBar(
    title: String,
    isDemoMode: Boolean,
    hardwareStatus: HardwareStatus,
    onModeClick: () -> Unit = {}
) {
    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Default.Medication,
                            contentDescription = "MedQ Icon",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Smart Medicine Dispenser",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        actions = {
            // Demo Mode Badge
            Surface(
                onClick = onModeClick,
                shape = RoundedCornerShape(16.dp),
                color = if (isDemoMode) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.18f) else StatusSuccess.copy(alpha = 0.18f),
                border = BorderStroke(
                    1.dp,
                    if (isDemoMode) MaterialTheme.colorScheme.tertiary else StatusSuccess
                ),
                modifier = Modifier
                    .padding(end = 12.dp)
                    .testTag("mode_toggle_badge")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isDemoMode) MaterialTheme.colorScheme.tertiary else StatusSuccess)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isDemoMode) "DEMO MODE" else "HARDWARE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isDemoMode) MaterialTheme.colorScheme.tertiary else StatusSuccess
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    )
}

@Composable
fun CompartmentCard(
    compartmentInfo: CompartmentInfo,
    onDispenseClick: () -> Unit,
    onEditClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val compNum = compartmentInfo.compartmentNumber
    val med = compartmentInfo.medicine
    val isEmpty = med == null

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("compartment_card_$compNum")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Compartment badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "COMPARTMENT $compNum",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                // Status pill
                val (statusColor, statusText) = when {
                    isEmpty -> Pair(Color.Gray, "Empty")
                    !med!!.enabled -> Pair(StatusWarning, "Disabled")
                    else -> Pair(StatusSuccess, "Ready")
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = statusColor.copy(alpha = 0.15f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (!isEmpty && med != null) {
                Text(
                    text = med.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Dosage: ${med.dosage}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (med.description.isNotBlank()) {
                    Text(
                        text = med.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Outlined.AccessTime,
                        contentDescription = "Schedule",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Next: ${compartmentInfo.nextScheduleTime ?: "Manual"}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onEditClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("edit_comp_${compNum}_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Outlined.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Configure")
                    }

                    Button(
                        onClick = onDispenseClick,
                        enabled = med.enabled,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .weight(1.2f)
                            .height(44.dp)
                            .testTag("dispense_now_comp_${compNum}_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Dispense", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Dispense Now", fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Outlined.AddCircleOutline,
                            contentDescription = "Empty",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tray is Empty",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = onEditClick,
                            modifier = Modifier.testTag("add_medicine_comp_${compNum}_btn"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Assign Medicine")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DispensingProgressModal(
    visible: Boolean,
    target: Triple<String, String, Int>?,
    state: DispensingState,
    statusMessage: String,
    onDismiss: () -> Unit
) {
    if (!visible) return

    val infiniteTransition = rememberInfiniteTransition(label = "dispense_anim")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotate_anim"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_anim"
    )

    Dialog(onDismissRequest = {
        if (state == DispensingState.COMPLETED || state == DispensingState.FAILED || state == DispensingState.TIMEOUT) {
            onDismiss()
        }
    }) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("dispensing_progress_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Text(
                    text = "MedQ Dispenser In Progress",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                if (target != null) {
                    Text(
                        text = "${target.first} (${target.second})",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Compartment ${target.third}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Visual Animation Node
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(CircleShape)
                        .background(
                            when (state) {
                                DispensingState.COMPLETED -> StatusSuccess.copy(alpha = 0.15f)
                                DispensingState.FAILED, DispensingState.TIMEOUT -> StatusError.copy(alpha = 0.15f)
                                else -> MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    when (state) {
                        DispensingState.CHECKING -> {
                            Icon(
                                Icons.Default.Sync,
                                contentDescription = "Checking",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(48.dp)
                                    .rotate(rotation)
                            )
                        }
                        DispensingState.ALERTING -> {
                            Icon(
                                Icons.Default.VolumeUp,
                                contentDescription = "Buzzer",
                                tint = StatusWarning,
                                modifier = Modifier
                                    .size(52.dp)
                                    .scale(pulse)
                            )
                        }
                        DispensingState.SELECTING_COMPARTMENT -> {
                            Icon(
                                Icons.Default.Autorenew,
                                contentDescription = "Rotating",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(52.dp)
                                    .rotate(rotation)
                            )
                        }
                        DispensingState.OPENING_GATE, DispensingState.CLOSING_GATE -> {
                            Icon(
                                Icons.Default.MeetingRoom,
                                contentDescription = "Gate",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(50.dp)
                            )
                        }
                        DispensingState.WAITING_FOR_IR -> {
                            Icon(
                                Icons.Default.Sensors,
                                contentDescription = "IR Sensor",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier
                                    .size(52.dp)
                                    .scale(pulse)
                            )
                        }
                        DispensingState.MEDICINE_DETECTED -> {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = "Detected",
                                tint = StatusSuccess,
                                modifier = Modifier.size(54.dp)
                            )
                        }
                        DispensingState.COMPLETED -> {
                            Icon(
                                Icons.Default.TaskAlt,
                                contentDescription = "Success",
                                tint = StatusSuccess,
                                modifier = Modifier.size(60.dp)
                            )
                        }
                        DispensingState.TIMEOUT -> {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = "Timeout",
                                tint = StatusWarning,
                                modifier = Modifier.size(56.dp)
                            )
                        }
                        DispensingState.FAILED -> {
                            Icon(
                                Icons.Default.ErrorOutline,
                                contentDescription = "Failed",
                                tint = StatusError,
                                modifier = Modifier.size(56.dp)
                            )
                        }
                        else -> {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // State Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (state) {
                        DispensingState.COMPLETED -> StatusSuccess.copy(alpha = 0.2f)
                        DispensingState.FAILED, DispensingState.TIMEOUT -> StatusError.copy(alpha = 0.2f)
                        else -> MaterialTheme.colorScheme.primaryContainer
                    }
                ) {
                    Text(
                        text = state.label,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (state) {
                            DispensingState.COMPLETED -> StatusSuccess
                            DispensingState.FAILED, DispensingState.TIMEOUT -> StatusError
                            else -> MaterialTheme.colorScheme.onPrimaryContainer
                        },
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = statusMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Linear indicator for steps
                val progress = when (state) {
                    DispensingState.IDLE -> 0.05f
                    DispensingState.CHECKING -> 0.15f
                    DispensingState.ALERTING -> 0.30f
                    DispensingState.SELECTING_COMPARTMENT -> 0.45f
                    DispensingState.OPENING_GATE -> 0.60f
                    DispensingState.WAITING_FOR_IR -> 0.75f
                    DispensingState.MEDICINE_DETECTED -> 0.88f
                    DispensingState.CLOSING_GATE -> 0.95f
                    DispensingState.COMPLETED -> 1.0f
                    else -> 1.0f
                }
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (state == DispensingState.COMPLETED) StatusSuccess else MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Action button
                val isDone = state == DispensingState.COMPLETED || state == DispensingState.FAILED || state == DispensingState.TIMEOUT
                Button(
                    onClick = onDismiss,
                    enabled = isDone,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("dismiss_dispense_modal_btn")
                ) {
                    Text(if (isDone) "Done" else "Dispensing in progress...")
                }
            }
        }
    }
}
