package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ========================================================
// MedQ Professional Medical + IoT Color Palette
// ========================================================

// Dark Theme: Deep Navy / Charcoal Architecture
val MedQDarkBg = Color(0xFF0B111E)         // Deep dark navy-charcoal canvas
val MedQDarkSurface = Color(0xFF10192B)    // Container surface
val MedQDarkCard = Color(0xFF152238)       // Slightly lighter card container
val MedQDarkBorder = Color(0xFF22344E)     // Subtle, crisp card border

// Light Theme: Clean Clinical Precision
val MedQLightBg = Color(0xFFF8FAFC)        // Clean clinical off-white
val MedQLightSurface = Color(0xFFFFFFFF)   // Pure white surfaces
val MedQLightCard = Color(0xFFF1F5F9)      // Soft slate card container
val MedQLightBorder = Color(0xFFE2E8F0)    // Subtle gray-slate border

// Primary Medical Accents (Clean, non-neon clinical teal/blue)
val MedQPrimaryTeal = Color(0xFF0D9488)    // Refined clinical teal
val MedQPrimaryTealDark = Color(0xFF14B8A6)// Calibrated for dark contrast
val MedQPrimaryContainerDark = Color(0xFF113838) // Low saturation deep container
val MedQOnPrimaryContainerDark = Color(0xFF99F6E4)

val MedQPrimaryBlue = Color(0xFF0284C7)    // Medical azure
val MedQPrimaryBlueDark = Color(0xFF38BDF8)// Readable azure on dark
val MedQSecondary = Color(0xFF0EA5E9)      // Secondary accent blue

// Standardized Clinical Status Colors
val StatusSuccess = Color(0xFF10B981)      // Green for successful/completed
val StatusSuccessContainer = Color(0xFF063321)
val StatusWarning = Color(0xFFF59E0B)      // Amber for warnings/pending
val StatusWarningContainer = Color(0xFF3A2404)
val StatusError = Color(0xFFEF4444)        // Red for errors/missed
val StatusErrorContainer = Color(0xFF3B1212)
val StatusInfo = Color(0xFF38BDF8)

// Compatibility tokens
val Purple80 = MedQPrimaryTealDark
val PurpleGrey80 = Color(0xFF88A0B8)
val Pink80 = Color(0xFF64D2EC)
val Purple40 = MedQPrimaryTeal
val PurpleGrey40 = Color(0xFF4A5568)
val Pink40 = MedQPrimaryBlue
