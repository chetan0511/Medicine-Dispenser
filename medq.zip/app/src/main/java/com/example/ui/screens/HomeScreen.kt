package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CompartmentInfo
import com.example.ui.components.CompartmentCard
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MedQViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(
    viewModel: MedQViewModel,
    onNavigate: (AppScreen) -> Unit,
    onAddMedicineForCompartment: (Int) -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val medicines by viewModel.medicines.collectAsState()
    val schedules by viewModel.schedules.collectAsState()
    val history by viewModel.history.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val hardwareStatus by viewModel.hardwareStatus.collectAsState()

    val isDemoMode = settings?.isDemoMode ?: true
    val compartmentsInfo = remember(medicines, schedules) {
        viewModel.getCompartmentsInfo(medicines, schedules)
    }
    val adherenceStats = remember(history) {
        viewModel.getAdherenceStats(history)
    }

    val currentDateStr = remember {
        SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.getDefault()).format(Date())
    }
    val currentTimeStr = remember {
        SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
    }

    // Find next upcoming dose
    val nextUpcomingMed = compartmentsInfo.firstOrNull { it.status == "UPCOMING" && it.medicine != null }

    var showQuickDispenseDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header Greeting & Date
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Good day,",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = currentUser?.name ?: "Patient",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Device connectivity pill
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (hardwareStatus.isOnline) StatusSuccess.copy(alpha = 0.15f) else StatusError.copy(alpha = 0.15f)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (hardwareStatus.isOnline) StatusSuccess else StatusError)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isDemoMode) "ESP32 (Demo)" else if (hardwareStatus.isOnline) "ESP32 Online" else "Offline",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (hardwareStatus.isOnline) StatusSuccess else StatusError
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = currentDateStr,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = currentTimeStr,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        // 2. Next Medicine Hero Banner
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(54.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Alarm,
                                contentDescription = "Next Dose",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Next Scheduled Dose",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                        Text(
                            text = nextUpcomingMed?.medicine?.name ?: "All doses completed today",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        if (nextUpcomingMed?.medicine != null) {
                            Text(
                                text = "${nextUpcomingMed.medicine.dosage} • Compartment ${nextUpcomingMed.compartmentNumber} at ${nextUpcomingMed.nextScheduleTime}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.9f)
                            )
                        }
                    }

                    if (nextUpcomingMed?.medicine != null) {
                        Button(
                            onClick = {
                                viewModel.startDispense(
                                    compartment = nextUpcomingMed.compartmentNumber,
                                    medicineName = nextUpcomingMed.medicine.name,
                                    dosage = nextUpcomingMed.medicine.dosage,
                                    medicineId = nextUpcomingMed.medicine.id
                                )
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("hero_dispense_now_btn")
                        ) {
                            Text("Take")
                        }
                    }
                }
            }
        }

        // 3. Adherence Metrics Grid
        item {
            Column {
                Text(
                    text = "Dose Adherence & Tracking",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Completed
                    MetricCard(
                        title = "Completed",
                        count = adherenceStats.completedDoses.toString(),
                        color = StatusSuccess,
                        icon = Icons.Default.CheckCircle,
                        modifier = Modifier.weight(1f)
                    )
                    // Pending
                    MetricCard(
                        title = "Pending",
                        count = "2",
                        color = StatusWarning,
                        icon = Icons.Default.HourglassTop,
                        modifier = Modifier.weight(1f)
                    )
                    // Missed
                    MetricCard(
                        title = "Missed",
                        count = adherenceStats.missedDoses.toString(),
                        color = StatusError,
                        icon = Icons.Default.Cancel,
                        modifier = Modifier.weight(1f)
                    )
                    // Score
                    MetricCard(
                        title = "Adherence",
                        count = "${adherenceStats.adherencePercentage}%",
                        color = MaterialTheme.colorScheme.primary,
                        icon = Icons.Default.Analytics,
                        modifier = Modifier.weight(1.1f)
                    )
                }
            }
        }

        // 4. Quick Actions Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionItem(
                    label = "Add Medicine",
                    icon = Icons.Default.Add,
                    onClick = { onNavigate(AppScreen.MEDICINES) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_action_add_med")
                )
                QuickActionItem(
                    label = "Dispense Now",
                    icon = Icons.Default.PlayCircle,
                    onClick = { showQuickDispenseDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_action_dispense_now")
                )
                QuickActionItem(
                    label = "Hardware",
                    icon = Icons.Default.Memory,
                    onClick = { onNavigate(AppScreen.CONTROL) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_action_device_status")
                )
                QuickActionItem(
                    label = "History",
                    icon = Icons.Default.History,
                    onClick = { onNavigate(AppScreen.HISTORY) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_action_history")
                )
            }
        }

        // 5. 4 Compartment Tray Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Medicine Tray Compartments",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "4 Bays Available",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(compartmentsInfo) { info ->
            CompartmentCard(
                compartmentInfo = info,
                onDispenseClick = {
                    val med = info.medicine
                    if (med != null) {
                        viewModel.startDispense(
                            compartment = info.compartmentNumber,
                            medicineName = med.name,
                            dosage = med.dosage,
                            medicineId = med.id
                        )
                    }
                },
                onEditClick = {
                    onAddMedicineForCompartment(info.compartmentNumber)
                }
            )
        }
    }

    // Quick Dispense Modal to choose compartment
    if (showQuickDispenseDialog) {
        AlertDialog(
            onDismissRequest = { showQuickDispenseDialog = false },
            title = { Text("Manual Dispense Selector") },
            text = {
                Column {
                    Text("Select a compartment to trigger instant medicine dispensing:")
                    Spacer(modifier = Modifier.height(14.dp))
                    compartmentsInfo.forEach { cInfo ->
                        val med = cInfo.medicine
                        OutlinedButton(
                            onClick = {
                                showQuickDispenseDialog = false
                                viewModel.startDispense(
                                    compartment = cInfo.compartmentNumber,
                                    medicineName = med?.name ?: "Compartment ${cInfo.compartmentNumber} Pill",
                                    dosage = med?.dosage ?: "Standard Dose",
                                    medicineId = med?.id
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Compartment ${cInfo.compartmentNumber}: ${med?.name ?: "(Empty)"}")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQuickDispenseDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun MetricCard(
    title: String,
    count: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = title, tint = color, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = count,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun QuickActionItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier.height(72.dp)
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                icon,
                contentDescription = label,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                fontSize = 11.sp
            )
        }
    }
}
