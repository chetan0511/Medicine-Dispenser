package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.MedQDatabase
import com.example.data.model.*
import com.example.data.remote.DispenseResult
import com.example.data.remote.Esp32Client
import com.example.data.repository.MedQRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class AppScreen {
    SPLASH,
    AUTH,
    HOME,
    MEDICINES,
    CONTROL,
    HISTORY,
    SETTINGS
}

data class UiNotification(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

class MedQViewModel(application: Application) : AndroidViewModel(application) {
    private val database = MedQDatabase.getDatabase(application)
    private val esp32Client = Esp32Client()
    val repository = MedQRepository(database, esp32Client)

    private val _currentScreen = MutableStateFlow(AppScreen.SPLASH)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    val currentUser = repository.currentUser.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val medicines = repository.allMedicines.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val schedules = repository.allSchedules.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val history = repository.dispensingHistory.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val events = repository.deviceEvents.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val settings = repository.appSettings.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        AppSettingsEntity()
    )

    private val _hardwareStatus = MutableStateFlow(HardwareStatus())
    val hardwareStatus: StateFlow<HardwareStatus> = _hardwareStatus.asStateFlow()

    private val _isRefreshingHardware = MutableStateFlow(false)
    val isRefreshingHardware: StateFlow<Boolean> = _isRefreshingHardware.asStateFlow()

    // Dispensing execution state
    private val _activeDispensingState = MutableStateFlow(DispensingState.IDLE)
    val activeDispensingState: StateFlow<DispensingState> = _activeDispensingState.asStateFlow()

    private val _dispensingStatusMessage = MutableStateFlow("")
    val dispensingStatusMessage: StateFlow<String> = _dispensingStatusMessage.asStateFlow()

    private val _isDispensingModalVisible = MutableStateFlow(false)
    val isDispensingModalVisible: StateFlow<Boolean> = _isDispensingModalVisible.asStateFlow()

    private val _currentDispensingTarget = MutableStateFlow<Triple<String, String, Int>?>(null)
    val currentDispensingTarget: StateFlow<Triple<String, String, Int>?> = _currentDispensingTarget.asStateFlow()

    // Transient UI toast / notification
    private val _uiNotification = MutableSharedFlow<UiNotification>()
    val uiNotification: SharedFlow<UiNotification> = _uiNotification.asSharedFlow()

    // History filter & search
    private val _historyFilter = MutableStateFlow("ALL") // "TODAY", "WEEK", "MONTH", "ALL"
    val historyFilter: StateFlow<String> = _historyFilter.asStateFlow()

    private val _historySearchQuery = MutableStateFlow("")
    val historySearchQuery: StateFlow<String> = _historySearchQuery.asStateFlow()

    // Auth Form State
    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeDefaultsIfNeeded()
            refreshHardwareStatus()
        }
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun setHistoryFilter(filter: String) {
        _historyFilter.value = filter
    }

    fun setHistorySearchQuery(query: String) {
        _historySearchQuery.value = query
    }

    fun refreshHardwareStatus() {
        viewModelScope.launch {
            _isRefreshingHardware.value = true
            try {
                val status = repository.checkHardwareStatus()
                _hardwareStatus.value = status
            } finally {
                _isRefreshingHardware.value = false
            }
        }
    }

    // Compartment Info calculation
    fun getCompartmentsInfo(
        medList: List<MedicineEntity>,
        schList: List<ScheduleEntity>
    ): List<CompartmentInfo> {
        return (1..4).map { compNumber ->
            val med = medList.firstOrNull { it.compartment == compNumber }
            if (med == null) {
                CompartmentInfo(
                    compartmentNumber = compNumber,
                    medicine = null,
                    nextScheduleTime = null,
                    status = "EMPTY"
                )
            } else {
                val medSchedules = schList.filter { it.medicineId == med.id && it.enabled }
                val nextTime = medSchedules.firstOrNull()?.time ?: "Manual Only"
                val status = if (med.enabled) "UPCOMING" else "PAUSED"
                CompartmentInfo(
                    compartmentNumber = compNumber,
                    medicine = med,
                    nextScheduleTime = nextTime,
                    status = status
                )
            }
        }
    }

    // Adherence Stats calculation
    fun getAdherenceStats(historyList: List<DispensingHistoryEntity>): AdherenceStats {
        if (historyList.isEmpty()) {
            return AdherenceStats(0, 0, 0, 0, 0, 100)
        }
        val total = historyList.size
        val completed = historyList.count { it.status == "dispensed" || it.status == "manual" }
        val missed = historyList.count { it.status == "missed" }
        val failed = historyList.count { it.status == "failed" }
        val notDetected = historyList.count { it.status == "not_detected" }
        val percentage = if (total > 0) ((completed.toDouble() / total) * 100).toInt() else 100

        return AdherenceStats(
            totalDoses = total,
            completedDoses = completed,
            missedDoses = missed,
            failedDoses = failed,
            notDetectedDoses = notDetected,
            adherencePercentage = percentage
        )
    }

    // Dispensing execution
    fun startDispense(
        compartment: Int,
        medicineName: String,
        dosage: String,
        medicineId: String? = null,
        scheduledTime: String = "Now"
    ) {
        if (_activeDispensingState.value != DispensingState.IDLE &&
            _activeDispensingState.value != DispensingState.COMPLETED &&
            _activeDispensingState.value != DispensingState.FAILED &&
            _activeDispensingState.value != DispensingState.TIMEOUT
        ) {
            return // prevent duplicate clicks while running
        }

        _currentDispensingTarget.value = Triple(medicineName, dosage, compartment)
        _isDispensingModalVisible.value = true
        _activeDispensingState.value = DispensingState.CHECKING
        _dispensingStatusMessage.value = "Starting MedQ dispenser sequence..."

        viewModelScope.launch {
            val result = repository.executeDispensing(
                compartment = compartment,
                medicineName = medicineName,
                dosage = dosage,
                medicineId = medicineId,
                scheduledTime = scheduledTime,
                onStateChanged = { state, msg ->
                    _activeDispensingState.value = state
                    _dispensingStatusMessage.value = msg
                }
            )

            // Trigger notification
            _uiNotification.emit(
                UiNotification(
                    title = if (result.success) "Medicine Dispensed" else "Dispensing Alert",
                    message = result.message
                )
            )
            refreshHardwareStatus()
        }
    }

    fun dismissDispensingModal() {
        _isDispensingModalVisible.value = false
        _activeDispensingState.value = DispensingState.IDLE
        _dispensingStatusMessage.value = ""
        _currentDispensingTarget.value = null
    }

    // Manual Hardware Controls
    fun testServo1(compartment: Int) {
        viewModelScope.launch {
            val s = settings.value ?: AppSettingsEntity()
            if (s.isDemoMode) {
                _uiNotification.emit(UiNotification(title = "Demo Mode", message = "Servo 1 rotated to Compartment $compartment angle."))
            } else {
                val ok = esp32Client.triggerServo(s.esp32Ip, s.esp32Port, servoNumber = 1, action = "select", compartment = compartment)
                _uiNotification.emit(
                    UiNotification(
                        title = "Hardware Test",
                        message = if (ok) "Servo 1 moved to Compartment $compartment" else "Failed to send command to ESP32"
                    )
                )
            }
        }
    }

    fun testServo2(action: String) {
        viewModelScope.launch {
            val s = settings.value ?: AppSettingsEntity()
            if (s.isDemoMode) {
                _uiNotification.emit(UiNotification(title = "Demo Mode", message = "Servo 2 gate $action simulated."))
            } else {
                val ok = esp32Client.triggerServo(s.esp32Ip, s.esp32Port, servoNumber = 2, action = action)
                _uiNotification.emit(
                    UiNotification(
                        title = "Hardware Test",
                        message = if (ok) "Servo 2 gate $action executed" else "Failed to send command to ESP32"
                    )
                )
            }
        }
    }

    fun testBuzzer() {
        viewModelScope.launch {
            val s = settings.value ?: AppSettingsEntity()
            if (s.isDemoMode) {
                _uiNotification.emit(UiNotification(title = "Demo Mode", message = "Buzzer beep sound alerted for 1000ms."))
            } else {
                val ok = esp32Client.triggerBuzzer(s.esp32Ip, s.esp32Port, enabled = true, durationMs = 1200)
                _uiNotification.emit(
                    UiNotification(
                        title = "Buzzer Test",
                        message = if (ok) "Buzzer triggered for 1200ms" else "Failed to reach ESP32 buzzer"
                    )
                )
            }
        }
    }

    fun testIrSensor() {
        viewModelScope.launch {
            val s = settings.value ?: AppSettingsEntity()
            if (s.isDemoMode) {
                _uiNotification.emit(UiNotification(title = "Demo Mode", message = "IR Sensor Beam is Clear (Waiting for obstacle)."))
            } else {
                val detected = esp32Client.checkIrSensor(s.esp32Ip, s.esp32Port)
                _uiNotification.emit(
                    UiNotification(
                        title = "IR Sensor Check",
                        message = if (detected) "Obstacle / Pill Detected in aperture!" else "Beam Clear (No obstacle)"
                    )
                )
            }
        }
    }

    // Medicine CRUD
    fun saveMedicine(
        id: String?,
        name: String,
        dosage: String,
        desc: String,
        compartment: Int,
        enabled: Boolean,
        schedules: List<String>,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.saveMedicine(id, name, dosage, desc, compartment, enabled, schedules)
            res.onSuccess {
                _uiNotification.emit(UiNotification(title = "Saved", message = "${it.name} saved in Compartment $compartment"))
                onSuccess()
            }.onFailure {
                _uiNotification.emit(UiNotification(title = "Error", message = it.message ?: "Failed to save medicine"))
            }
        }
    }

    fun deleteMedicine(id: String) {
        viewModelScope.launch {
            repository.deleteMedicine(id)
            _uiNotification.emit(UiNotification(title = "Deleted", message = "Medicine removed."))
        }
    }

    fun toggleMedicine(id: String, enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleMedicineEnabled(id, enabled)
        }
    }

    // Settings actions
    fun toggleDemoMode(enabled: Boolean) {
        viewModelScope.launch {
            val current = settings.value ?: AppSettingsEntity()
            repository.updateSettings(current.copy(isDemoMode = enabled))
            refreshHardwareStatus()
            _uiNotification.emit(
                UiNotification(
                    title = "Mode Switched",
                    message = if (enabled) "Demo Mode Active (Physical hardware not required)" else "Real Hardware Mode Active (Connecting to ESP32)"
                )
            )
        }
    }

    fun updateEsp32Ip(ip: String, port: Int) {
        viewModelScope.launch {
            val current = settings.value ?: AppSettingsEntity()
            repository.updateSettings(current.copy(esp32Ip = ip.trim(), esp32Port = port))
            refreshHardwareStatus()
            _uiNotification.emit(UiNotification(title = "Settings Updated", message = "ESP32 IP set to $ip:$port"))
        }
    }

    fun updateThemeMode(mode: String) {
        viewModelScope.launch {
            val current = settings.value ?: AppSettingsEntity()
            repository.updateSettings(current.copy(themeMode = mode))
            _uiNotification.emit(
                UiNotification(
                    title = "Theme Updated",
                    message = when (mode) {
                        "LIGHT" -> "Light theme activated"
                        "DARK" -> "Dark theme activated"
                        else -> "System default theme activated"
                    }
                )
            )
        }
    }

    fun updatePreferences(
        notifications: Boolean,
        sound: Boolean,
        vibration: Boolean,
        is24Hour: Boolean
    ) {
        viewModelScope.launch {
            val current = settings.value ?: AppSettingsEntity()
            repository.updateSettings(
                current.copy(
                    notificationEnabled = notifications,
                    soundEnabled = sound,
                    vibrationEnabled = vibration,
                    is24HourFormat = is24Hour
                )
            )
            _uiNotification.emit(UiNotification(title = "Preferences Saved", message = "App preferences updated successfully."))
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            _uiNotification.emit(UiNotification(title = "History Cleared", message = "Dispensing records cleared."))
        }
    }

    fun resetApp() {
        viewModelScope.launch {
            repository.resetAllData()
            refreshHardwareStatus()
            _uiNotification.emit(UiNotification(title = "App Reset", message = "Reset to default demo data."))
        }
    }

    // Auth actions
    fun login(email: String, pass: String, onSuccess: () -> Unit) {
        _isAuthLoading.value = true
        _authError.value = null
        viewModelScope.launch {
            try {
                val res = repository.login(email.trim(), pass)
                res.onSuccess {
                    _currentScreen.value = AppScreen.HOME
                    onSuccess()
                }.onFailure {
                    _authError.value = it.message ?: "Authentication failed"
                }
            } finally {
                _isAuthLoading.value = false
            }
        }
    }

    fun register(name: String, email: String, pass: String, confirmPass: String, onSuccess: () -> Unit) {
        if (pass.length < 8) {
            _authError.value = "Password must be at least 8 characters long."
            return
        }
        if (pass != confirmPass) {
            _authError.value = "Passwords do not match."
            return
        }
        _isAuthLoading.value = true
        _authError.value = null
        viewModelScope.launch {
            try {
                val res = repository.register(name.trim(), email.trim(), pass)
                res.onSuccess {
                    _currentScreen.value = AppScreen.HOME
                    onSuccess()
                }.onFailure {
                    _authError.value = it.message ?: "Registration failed"
                }
            } finally {
                _isAuthLoading.value = false
            }
        }
    }

    fun updateProfile(name: String, email: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val ok = repository.updateProfile(name, email)
            if (ok) {
                _uiNotification.emit(UiNotification(title = "Profile Updated", message = "User profile saved."))
                onSuccess()
            }
        }
    }

    fun changePassword(oldPass: String, newPass: String, onSuccess: () -> Unit) {
        if (newPass.length < 8) {
            viewModelScope.launch {
                _uiNotification.emit(UiNotification(title = "Error", message = "Password must be at least 8 characters."))
            }
            return
        }
        viewModelScope.launch {
            val res = repository.changePassword(oldPass, newPass)
            res.onSuccess {
                _uiNotification.emit(UiNotification(title = "Success", message = "Password changed successfully."))
                onSuccess()
            }.onFailure {
                _uiNotification.emit(UiNotification(title = "Error", message = it.message ?: "Failed to change password."))
            }
        }
    }

    fun logout() {
        _currentScreen.value = AppScreen.AUTH
    }
}
