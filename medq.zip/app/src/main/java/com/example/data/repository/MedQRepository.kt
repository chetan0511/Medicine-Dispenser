package com.example.data.repository

import com.example.data.local.MedQDatabase
import com.example.data.model.*
import com.example.data.remote.DispenseResult
import com.example.data.remote.Esp32Client
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.text.SimpleDateFormat
import java.util.*

class MedQRepository(
    private val database: MedQDatabase,
    private val esp32Client: Esp32Client = Esp32Client()
) {
    val currentUser: Flow<UserEntity?> = database.userDao().getCurrentUser()
    val allMedicines: Flow<List<MedicineEntity>> = database.medicineDao().getAllMedicines()
    val allSchedules: Flow<List<ScheduleEntity>> = database.scheduleDao().getAllSchedules()
    val dispensingHistory: Flow<List<DispensingHistoryEntity>> = database.dispensingHistoryDao().getAllHistory()
    val deviceEvents: Flow<List<DeviceEventEntity>> = database.deviceEventDao().getAllEvents()
    val appSettings: Flow<AppSettingsEntity?> = database.appSettingsDao().getSettings()

    suspend fun initializeDefaultsIfNeeded() {
        // Seed initial user if none
        val existingUser = database.userDao().getCurrentUser().firstOrNull()
        if (existingUser == null) {
            database.userDao().insertUser(
                UserEntity(
                    id = "user_demo_01",
                    name = "Alex Johnson",
                    email = "patient@medq.health",
                    passwordHash = "password123"
                )
            )
        }

        // Seed initial settings if none
        val existingSettings = database.appSettingsDao().getSettingsSync()
        if (existingSettings == null) {
            database.appSettingsDao().insertOrUpdateSettings(
                AppSettingsEntity(
                    id = 1,
                    esp32Ip = "192.168.4.1",
                    esp32Port = 80,
                    isDemoMode = true,
                    notificationEnabled = true,
                    soundEnabled = true,
                    vibrationEnabled = true,
                    is24HourFormat = false,
                    themeMode = "SYSTEM"
                )
            )
        }

        // Seed initial medicines if empty
        val existingMedicines = database.medicineDao().getAllMedicines().firstOrNull()
        if (existingMedicines.isNullOrEmpty()) {
            val med1 = MedicineEntity(
                id = "med_1",
                name = "Paracetamol",
                dosage = "500 mg",
                description = "Pain relief & fever reducer, take with water",
                compartment = 1,
                enabled = true
            )
            val med2 = MedicineEntity(
                id = "med_2",
                name = "Vitamin C & Zinc",
                dosage = "1000 mg",
                description = "Immune support, daily morning booster",
                compartment = 2,
                enabled = true
            )
            val med3 = MedicineEntity(
                id = "med_3",
                name = "Metformin",
                dosage = "500 mg",
                description = "Blood sugar management, take after meals",
                compartment = 3,
                enabled = true
            )
            database.medicineDao().insertMedicine(med1)
            database.medicineDao().insertMedicine(med2)
            database.medicineDao().insertMedicine(med3)

            // Schedules
            database.scheduleDao().insertSchedule(
                ScheduleEntity(
                    id = "sch_1",
                    medicineId = med1.id,
                    time = "08:00 AM",
                    frequency = "Daily",
                    selectedDays = "All",
                    reminderEnabled = true,
                    enabled = true
                )
            )
            database.scheduleDao().insertSchedule(
                ScheduleEntity(
                    id = "sch_2",
                    medicineId = med1.id,
                    time = "08:00 PM",
                    frequency = "Daily",
                    selectedDays = "All",
                    reminderEnabled = true,
                    enabled = true
                )
            )
            database.scheduleDao().insertSchedule(
                ScheduleEntity(
                    id = "sch_3",
                    medicineId = med2.id,
                    time = "01:00 PM",
                    frequency = "Daily",
                    selectedDays = "All",
                    reminderEnabled = true,
                    enabled = true
                )
            )
            database.scheduleDao().insertSchedule(
                ScheduleEntity(
                    id = "sch_4",
                    medicineId = med3.id,
                    time = "08:00 PM",
                    frequency = "Daily",
                    selectedDays = "All",
                    reminderEnabled = true,
                    enabled = true
                )
            )

            // Seed initial sample dispensing history
            val timeFmt = SimpleDateFormat("hh:mm a", Locale.getDefault())
            val dateFmt = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
            val now = System.currentTimeMillis()

            database.dispensingHistoryDao().insertHistory(
                DispensingHistoryEntity(
                    id = "hist_1",
                    medicineId = med1.id,
                    medicineName = med1.name,
                    dosage = med1.dosage,
                    compartment = med1.compartment,
                    scheduledTime = "08:00 AM",
                    actualTime = timeFmt.format(Date(now - 86400000L)),
                    status = "dispensed",
                    detectionResult = true,
                    mode = "demo",
                    errorMessage = null,
                    timestamp = now - 86400000L
                )
            )
            database.dispensingHistoryDao().insertHistory(
                DispensingHistoryEntity(
                    id = "hist_2",
                    medicineId = med2.id,
                    medicineName = med2.name,
                    dosage = med2.dosage,
                    compartment = med2.compartment,
                    scheduledTime = "01:00 PM",
                    actualTime = timeFmt.format(Date(now - 43200000L)),
                    status = "dispensed",
                    detectionResult = true,
                    mode = "demo",
                    errorMessage = null,
                    timestamp = now - 43200000L
                )
            )

            database.deviceEventDao().insertEvent(
                DeviceEventEntity(
                    id = "evt_init",
                    eventType = "SYSTEM_INIT",
                    description = "MedQ Smart Dispenser initialized successfully.",
                    severity = "INFO"
                )
            )
        }
    }

    // Auth methods
    suspend fun register(name: String, email: String, password: String):Result<UserEntity> {
        val existing = database.userDao().getUserByEmail(email)
        if (existing != null) {
            return Result.failure(Exception("An account with this email already exists."))
        }
        val newUser = UserEntity(
            id = UUID.randomUUID().toString(),
            name = name,
            email = email,
            passwordHash = password
        )
        database.userDao().insertUser(newUser)
        return Result.success(newUser)
    }

    suspend fun login(email: String, password: String): Result<UserEntity> {
        val user = database.userDao().getUserByEmail(email)
            ?: return Result.failure(Exception("No account found with this email."))
        if (user.passwordHash != password) {
            return Result.failure(Exception("Incorrect password."))
        }
        return Result.success(user)
    }

    suspend fun updateProfile(name: String, email: String): Boolean {
        val current = database.userDao().getCurrentUser().firstOrNull() ?: return false
        database.userDao().updateUser(current.copy(name = name, email = email))
        return true
    }

    suspend fun changePassword(oldPass: String, newPass: String): Result<Unit> {
        val current = database.userDao().getCurrentUser().firstOrNull()
            ?: return Result.failure(Exception("No user logged in."))
        if (current.passwordHash != oldPass) {
            return Result.failure(Exception("Current password does not match."))
        }
        database.userDao().updateUser(current.copy(passwordHash = newPass))
        return Result.success(Unit)
    }

    suspend fun logout() {
        // Keep demo account or clear session flag
    }

    // Medicine CRUD
    suspend fun saveMedicine(
        id: String?,
        name: String,
        dosage: String,
        description: String,
        compartment: Int,
        enabled: Boolean,
        schedules: List<String>
    ): Result<MedicineEntity> {
        if (name.isBlank()) return Result.failure(Exception("Medicine name cannot be empty."))
        if (dosage.isBlank()) return Result.failure(Exception("Dosage cannot be empty."))
        if (compartment !in 1..4) return Result.failure(Exception("Compartment must be between 1 and 4."))

        val medId = id ?: UUID.randomUUID().toString()
        val medicine = MedicineEntity(
            id = medId,
            name = name.trim(),
            dosage = dosage.trim(),
            description = description.trim(),
            compartment = compartment,
            enabled = enabled
        )
        database.medicineDao().insertMedicine(medicine)

        // Update schedules
        database.scheduleDao().deleteSchedulesForMedicine(medId)
        schedules.forEachIndexed { index, time ->
            if (time.isNotBlank()) {
                database.scheduleDao().insertSchedule(
                    ScheduleEntity(
                        id = "${medId}_sch_$index",
                        medicineId = medId,
                        time = time,
                        frequency = "Daily",
                        selectedDays = "All",
                        reminderEnabled = true,
                        enabled = true
                    )
                )
            }
        }
        return Result.success(medicine)
    }

    suspend fun deleteMedicine(id: String) {
        database.scheduleDao().deleteSchedulesForMedicine(id)
        database.medicineDao().deleteMedicineById(id)
    }

    suspend fun toggleMedicineEnabled(id: String, enabled: Boolean) {
        val med = database.medicineDao().getMedicineById(id) ?: return
        database.medicineDao().updateMedicine(med.copy(enabled = enabled))
    }

    // Dispensing Execution State Machine
    suspend fun executeDispensing(
        compartment: Int,
        medicineName: String,
        dosage: String,
        medicineId: String? = null,
        scheduledTime: String = "Now",
        onStateChanged: (DispensingState, String) -> Unit
    ): DispenseResult {
        val settings = database.appSettingsDao().getSettingsSync() ?: AppSettingsEntity()
        val isDemo = settings.isDemoMode
        val timeFmt = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val actualTimeStr = timeFmt.format(Date())

        if (isDemo) {
            // STEP 1: CHECKING
            onStateChanged(DispensingState.CHECKING, "Verifying tray alignment and status...")
            logDeviceEvent("CHECKING", "Checking compartment $compartment readiness (Demo Mode)", "INFO")
            delay(900)

            // STEP 2: ALERTING
            onStateChanged(DispensingState.ALERTING, "Buzzer activated: Alerting patient for $medicineName...")
            logDeviceEvent("BUZZER_ON", "Buzzer sound emitted for 1000ms", "INFO")
            delay(1000)

            // STEP 3: SELECTING_COMPARTMENT
            val angle = when(compartment) {
                1 -> 0
                2 -> 60
                3 -> 120
                else -> 180
            }
            onStateChanged(DispensingState.SELECTING_COMPARTMENT, "Servo 1 rotating carousel to $angle° (Compartment $compartment)...")
            logDeviceEvent("SERVO1_ROTATE", "Servo 1 positioned to $angle deg for Compartment $compartment", "INFO")
            delay(1100)

            // STEP 4: OPENING_GATE
            onStateChanged(DispensingState.OPENING_GATE, "Servo 2 opening dispensing trapdoor gate to 90°...")
            logDeviceEvent("SERVO2_OPEN", "Dispensing gate opened", "INFO")
            delay(900)

            // STEP 5: WAITING_FOR_IR
            onStateChanged(DispensingState.WAITING_FOR_IR, "Medicine falling - IR optical sensor monitoring aperture...")
            delay(1200)

            // STEP 6: MEDICINE_DETECTED
            onStateChanged(DispensingState.MEDICINE_DETECTED, "IR beam break confirmed: Pill successfully dropped!")
            logDeviceEvent("IR_DETECTED", "IR sensor detected pill passing through drop channel", "INFO")
            delay(800)

            // STEP 7: CLOSING_GATE
            onStateChanged(DispensingState.CLOSING_GATE, "Servo 2 returning gate to secure closed position (0°)...")
            logDeviceEvent("SERVO2_CLOSE", "Dispensing gate closed securely", "INFO")
            delay(800)

            // STEP 8: COMPLETED
            onStateChanged(DispensingState.COMPLETED, "Dispensing finished! Take with water.")
            logDeviceEvent("DISPENSE_SUCCESS", "Successfully dispensed $medicineName $dosage from Compartment $compartment", "INFO")

            // Record in Room History
            val history = DispensingHistoryEntity(
                id = UUID.randomUUID().toString(),
                medicineId = medicineId,
                medicineName = medicineName,
                dosage = dosage,
                compartment = compartment,
                scheduledTime = scheduledTime,
                actualTime = actualTimeStr,
                status = "dispensed",
                detectionResult = true,
                mode = "demo",
                errorMessage = null,
                timestamp = System.currentTimeMillis()
            )
            database.dispensingHistoryDao().insertHistory(history)

            return DispenseResult(
                success = true,
                message = "Successfully dispensed $medicineName ($dosage) from Compartment $compartment.",
                medicineDetected = true
            )
        } else {
            // REAL HARDWARE MODE
            onStateChanged(DispensingState.CHECKING, "Connecting to ESP32 at ${settings.esp32Ip}:${settings.esp32Port}...")
            logDeviceEvent("CHECKING", "Connecting to ESP32 at ${settings.esp32Ip}", "INFO")

            // Test hardware connection first
            val statusCheck = esp32Client.checkStatus(settings.esp32Ip, settings.esp32Port)
            if (!statusCheck.isOnline) {
                onStateChanged(DispensingState.FAILED, "ESP32 hardware offline or unreachable at ${settings.esp32Ip}")
                logDeviceEvent("DISPENSE_FAILED", "ESP32 offline at ${settings.esp32Ip}", "ERROR")

                val failHistory = DispensingHistoryEntity(
                    id = UUID.randomUUID().toString(),
                    medicineId = medicineId,
                    medicineName = medicineName,
                    dosage = dosage,
                    compartment = compartment,
                    scheduledTime = scheduledTime,
                    actualTime = actualTimeStr,
                    status = "failed",
                    detectionResult = false,
                    mode = "real",
                    errorMessage = "ESP32 device unreachable (${statusCheck.wifiStatus})",
                    timestamp = System.currentTimeMillis()
                )
                database.dispensingHistoryDao().insertHistory(failHistory)

                return DispenseResult(
                    success = false,
                    message = "Cannot dispense: ESP32 hardware is offline at ${settings.esp32Ip}. Check Wi-Fi connection.",
                    medicineDetected = false,
                    errorCode = "ESP32_OFFLINE"
                )
            }

            onStateChanged(DispensingState.ALERTING, "Hardware connected. Activating buzzer & tray...")
            onStateChanged(DispensingState.SELECTING_COMPARTMENT, "ESP32 rotating Servo 1 to Compartment $compartment...")
            delay(500)

            onStateChanged(DispensingState.OPENING_GATE, "ESP32 opening gate and awaiting IR drop sensor...")

            val result = esp32Client.dispense(
                ip = settings.esp32Ip,
                port = settings.esp32Port,
                compartment = compartment,
                medicineName = medicineName,
                dosage = dosage
            )

            if (result.success && result.medicineDetected) {
                onStateChanged(DispensingState.MEDICINE_DETECTED, "IR confirmed pill drop! Closing gate...")
                delay(600)
                onStateChanged(DispensingState.COMPLETED, "Medicine dispensed successfully!")
                logDeviceEvent("DISPENSE_SUCCESS", "Real hardware dispensed $medicineName from Compartment $compartment", "INFO")

                val history = DispensingHistoryEntity(
                    id = UUID.randomUUID().toString(),
                    medicineId = medicineId,
                    medicineName = medicineName,
                    dosage = dosage,
                    compartment = compartment,
                    scheduledTime = scheduledTime,
                    actualTime = actualTimeStr,
                    status = "dispensed",
                    detectionResult = true,
                    mode = "real",
                    errorMessage = null,
                    timestamp = System.currentTimeMillis()
                )
                database.dispensingHistoryDao().insertHistory(history)
            } else if (!result.medicineDetected && result.errorCode == null) {
                onStateChanged(DispensingState.TIMEOUT, "Medicine was not detected by IR sensor!")
                logDeviceEvent("DISPENSE_TIMEOUT", "IR sensor timed out - pill not detected in channel", "WARN")

                val timeoutHistory = DispensingHistoryEntity(
                    id = UUID.randomUUID().toString(),
                    medicineId = medicineId,
                    medicineName = medicineName,
                    dosage = dosage,
                    compartment = compartment,
                    scheduledTime = scheduledTime,
                    actualTime = actualTimeStr,
                    status = "not_detected",
                    detectionResult = false,
                    mode = "real",
                    errorMessage = "Medicine was not detected by IR proximity sensor.",
                    timestamp = System.currentTimeMillis()
                )
                database.dispensingHistoryDao().insertHistory(timeoutHistory)
            } else {
                onStateChanged(DispensingState.FAILED, result.message)
                logDeviceEvent("DISPENSE_FAILED", "Real hardware error: ${result.message}", "ERROR")

                val failHistory = DispensingHistoryEntity(
                    id = UUID.randomUUID().toString(),
                    medicineId = medicineId,
                    medicineName = medicineName,
                    dosage = dosage,
                    compartment = compartment,
                    scheduledTime = scheduledTime,
                    actualTime = actualTimeStr,
                    status = "failed",
                    detectionResult = false,
                    mode = "real",
                    errorMessage = result.message,
                    timestamp = System.currentTimeMillis()
                )
                database.dispensingHistoryDao().insertHistory(failHistory)
            }
            return result
        }
    }

    suspend fun updateSettings(settings: AppSettingsEntity) {
        database.appSettingsDao().insertOrUpdateSettings(settings)
    }

    suspend fun clearHistory() {
        database.dispensingHistoryDao().clearHistory()
    }

    suspend fun resetAllData() {
        database.dispensingHistoryDao().clearHistory()
        database.deviceEventDao().clearEvents()
        database.medicineDao().clearMedicines()
        database.scheduleDao().clearSchedules()
        initializeDefaultsIfNeeded()
    }

    suspend fun logDeviceEvent(eventType: String, description: String, severity: String = "INFO") {
        database.deviceEventDao().insertEvent(
            DeviceEventEntity(
                id = UUID.randomUUID().toString(),
                eventType = eventType,
                description = description,
                severity = severity,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun checkHardwareStatus(): HardwareStatus {
        val settings = database.appSettingsDao().getSettingsSync() ?: AppSettingsEntity()
        if (settings.isDemoMode) {
            return HardwareStatus(
                isOnline = true,
                esp32Ip = settings.esp32Ip,
                wifiStatus = "Simulation (Demo Mode)",
                rtcStatus = "Simulated (DS3231)",
                oledStatus = "Simulated (SSD1306)",
                irStatus = "Simulated (Beam Active)",
                servo1Status = "Simulated (Tray Calibrated)",
                servo2Status = "Simulated (Gate Calibrated)",
                buzzerStatus = "Simulated (Ready)",
                firmwareVersion = "v1.2.0-demo",
                lastSeenTime = "Active now"
            )
        }

        val result = esp32Client.checkStatus(settings.esp32Ip, settings.esp32Port)
        return HardwareStatus(
            isOnline = result.isOnline,
            esp32Ip = result.ip,
            wifiStatus = result.wifiStatus,
            rtcStatus = result.rtcStatus,
            oledStatus = result.oledStatus,
            irStatus = result.irStatus,
            servo1Status = result.servo1Status,
            servo2Status = result.servo2Status,
            buzzerStatus = result.buzzerStatus,
            firmwareVersion = if (result.isOnline) "v1.2.0-esp32" else "Unknown",
            lastSeenTime = if (result.isOnline) "Responded in ${result.responseTimeMs}ms" else "Offline"
        )
    }
}
