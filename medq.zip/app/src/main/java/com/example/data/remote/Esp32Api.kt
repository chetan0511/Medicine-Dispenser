package com.example.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class DispenseResult(
    val success: Boolean,
    val message: String,
    val medicineDetected: Boolean,
    val errorCode: String? = null
)

data class HardwareCheckResult(
    val isOnline: Boolean,
    val ip: String,
    val wifiStatus: String,
    val rtcStatus: String,
    val oledStatus: String,
    val irStatus: String,
    val servo1Status: String,
    val servo2Status: String,
    val buzzerStatus: String,
    val responseTimeMs: Long
)

class Esp32Client {
    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(4, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun checkStatus(ip: String, port: Int = 80): HardwareCheckResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val url = "http://$ip:$port/api/status"
        try {
            val request = Request.Builder()
                .url(url)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val duration = System.currentTimeMillis() - startTime
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: "{}"
                    val json = JSONObject(body)
                    HardwareCheckResult(
                        isOnline = true,
                        ip = ip,
                        wifiStatus = json.optString("wifi", "Connected"),
                        rtcStatus = json.optString("rtc", "OK (DS3231)"),
                        oledStatus = json.optString("oled", "OK (SSD1306)"),
                        irStatus = json.optString("ir", "Beam Clear"),
                        servo1Status = json.optString("servo1", "Ready"),
                        servo2Status = json.optString("servo2", "Ready"),
                        buzzerStatus = json.optString("buzzer", "Standby"),
                        responseTimeMs = duration
                    )
                } else {
                    HardwareCheckResult(
                        isOnline = false,
                        ip = ip,
                        wifiStatus = "HTTP Error ${response.code}",
                        rtcStatus = "Unknown",
                        oledStatus = "Unknown",
                        irStatus = "Unknown",
                        servo1Status = "Unknown",
                        servo2Status = "Unknown",
                        buzzerStatus = "Unknown",
                        responseTimeMs = duration
                    )
                }
            }
        } catch (e: Exception) {
            HardwareCheckResult(
                isOnline = false,
                ip = ip,
                wifiStatus = "Unreachable (${e.localizedMessage ?: "Timeout"})",
                rtcStatus = "Offline",
                oledStatus = "Offline",
                irStatus = "Offline",
                servo1Status = "Offline",
                servo2Status = "Offline",
                buzzerStatus = "Offline",
                responseTimeMs = System.currentTimeMillis() - startTime
            )
        }
    }

    suspend fun dispense(
        ip: String,
        port: Int = 80,
        compartment: Int,
        medicineName: String,
        dosage: String
    ): DispenseResult = withContext(Dispatchers.IO) {
        val url = "http://$ip:$port/api/dispense"
        try {
            val payload = JSONObject().apply {
                put("compartment", compartment)
                put("medicine", medicineName)
                put("dosage", dosage)
            }
            val requestBody = payload.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: "{}"
                if (response.isSuccessful) {
                    val json = JSONObject(body)
                    val success = json.optBoolean("success", false)
                    val detected = json.optBoolean("detected", false)
                    val message = json.optString("message", if (detected) "Medicine dispensed successfully" else "Medicine not detected")
                    DispenseResult(
                        success = success && detected,
                        message = message,
                        medicineDetected = detected
                    )
                } else {
                    DispenseResult(
                        success = false,
                        message = "ESP32 returned error code ${response.code}",
                        medicineDetected = false,
                        errorCode = "HTTP_${response.code}"
                    )
                }
            }
        } catch (e: Exception) {
            DispenseResult(
                success = false,
                message = "Failed to communicate with ESP32: ${e.localizedMessage ?: "Connection timed out"}",
                medicineDetected = false,
                errorCode = "NETWORK_ERROR"
            )
        }
    }

    suspend fun triggerServo(
        ip: String,
        port: Int = 80,
        servoNumber: Int,
        action: String,
        compartment: Int? = null,
        angle: Int? = null
    ): Boolean = withContext(Dispatchers.IO) {
        val url = "http://$ip:$port/api/servo"
        try {
            val payload = JSONObject().apply {
                put("servo", servoNumber)
                put("action", action)
                if (compartment != null) put("compartment", compartment)
                if (angle != null) put("angle", angle)
            }
            val request = Request.Builder()
                .url(url)
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            false
        }
    }

    suspend fun triggerBuzzer(
        ip: String,
        port: Int = 80,
        enabled: Boolean,
        durationMs: Int = 1000
    ): Boolean = withContext(Dispatchers.IO) {
        val url = "http://$ip:$port/api/buzzer"
        try {
            val payload = JSONObject().apply {
                put("enabled", enabled)
                put("durationMs", durationMs)
            }
            val request = Request.Builder()
                .url(url)
                .post(payload.toString().toRequestBody(jsonMediaType))
                .build()
            client.newCall(request).execute().use { it.isSuccessful }
        } catch (e: Exception) {
            false
        }
    }

    suspend fun checkIrSensor(ip: String, port: Int = 80): Boolean = withContext(Dispatchers.IO) {
        val url = "http://$ip:$port/api/ir"
        try {
            val request = Request.Builder().url(url).get().build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val json = JSONObject(response.body?.string() ?: "{}")
                    json.optBoolean("detected", false)
                } else false
            }
        } catch (e: Exception) {
            false
        }
    }
}
