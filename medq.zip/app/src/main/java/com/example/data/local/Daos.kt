package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users LIMIT 1")
    fun getCurrentUser(): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("DELETE FROM users")
    suspend fun clearUsers()
}

@Dao
interface MedicineDao {
    @Query("SELECT * FROM medicines ORDER BY compartment ASC")
    fun getAllMedicines(): Flow<List<MedicineEntity>>

    @Query("SELECT * FROM medicines WHERE id = :id LIMIT 1")
    suspend fun getMedicineById(id: String): MedicineEntity?

    @Query("SELECT * FROM medicines WHERE compartment = :compartment LIMIT 1")
    suspend fun getMedicineByCompartment(compartment: Int): MedicineEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedicine(medicine: MedicineEntity)

    @Update
    suspend fun updateMedicine(medicine: MedicineEntity)

    @Delete
    suspend fun deleteMedicine(medicine: MedicineEntity)

    @Query("DELETE FROM medicines WHERE id = :id")
    suspend fun deleteMedicineById(id: String)

    @Query("DELETE FROM medicines")
    suspend fun clearMedicines()
}

@Dao
interface ScheduleDao {
    @Query("SELECT * FROM schedules ORDER BY time ASC")
    fun getAllSchedules(): Flow<List<ScheduleEntity>>

    @Query("SELECT * FROM schedules WHERE medicineId = :medicineId")
    fun getSchedulesForMedicine(medicineId: String): Flow<List<ScheduleEntity>>

    @Query("SELECT * FROM schedules WHERE medicineId = :medicineId")
    suspend fun getSchedulesForMedicineList(medicineId: String): List<ScheduleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: ScheduleEntity)

    @Update
    suspend fun updateSchedule(schedule: ScheduleEntity)

    @Delete
    suspend fun deleteSchedule(schedule: ScheduleEntity)

    @Query("DELETE FROM schedules WHERE medicineId = :medicineId")
    suspend fun deleteSchedulesForMedicine(medicineId: String)

    @Query("DELETE FROM schedules")
    suspend fun clearSchedules()
}

@Dao
interface DispensingHistoryDao {
    @Query("SELECT * FROM dispensing_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<DispensingHistoryEntity>>

    @Query("SELECT * FROM dispensing_history WHERE timestamp >= :sinceTimestamp ORDER BY timestamp DESC")
    fun getHistorySince(sinceTimestamp: Long): Flow<List<DispensingHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: DispensingHistoryEntity)

    @Query("DELETE FROM dispensing_history")
    suspend fun clearHistory()
}

@Dao
interface DeviceEventDao {
    @Query("SELECT * FROM device_events ORDER BY timestamp DESC LIMIT 100")
    fun getAllEvents(): Flow<List<DeviceEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: DeviceEventEntity)

    @Query("DELETE FROM device_events")
    suspend fun clearEvents()
}

@Dao
interface AppSettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    fun getSettings(): Flow<AppSettingsEntity?>

    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    suspend fun getSettingsSync(): AppSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSettings(settings: AppSettingsEntity)
}
