package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey
    val id: String = "user_default",
    val name: String,
    val email: String,
    val passwordHash: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "medicines")
data class MedicineEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val dosage: String,
    val description: String = "",
    val compartment: Int, // 1, 2, 3, or 4
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "schedules")
data class ScheduleEntity(
    @PrimaryKey
    val id: String,
    val medicineId: String,
    val time: String, // "08:00 AM" or "14:00"
    val frequency: String = "Daily", // Daily, Weekdays, Weekends, Custom
    val selectedDays: String = "All", // "Mon,Tue,Wed,Thu,Fri,Sat,Sun"
    val reminderEnabled: Boolean = true,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "dispensing_history")
data class DispensingHistoryEntity(
    @PrimaryKey
    val id: String,
    val medicineId: String?,
    val medicineName: String,
    val dosage: String,
    val compartment: Int,
    val scheduledTime: String,
    val actualTime: String,
    val status: String, // "dispensed", "missed", "not_detected", "failed", "manual"
    val detectionResult: Boolean, // IR detection
    val mode: String, // "demo" or "real"
    val errorMessage: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "device_events")
data class DeviceEventEntity(
    @PrimaryKey
    val id: String,
    val eventType: String, // "SERVO_ACTIVATED", "IR_DETECTED", "BUZZER_ON", "RTC_OK", "CONNECT", "DISPENSE_SUCCESS", "DISPENSE_FAILED"
    val description: String,
    val severity: String = "INFO", // "INFO", "WARN", "ERROR"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val esp32Ip: String = "192.168.4.1",
    val esp32Port: Int = 80,
    val isDemoMode: Boolean = true,
    val notificationEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val is24HourFormat: Boolean = false,
    val themeMode: String = "SYSTEM" // "LIGHT", "DARK", "SYSTEM"
)

enum class DispensingState(val label: String, val stepIndex: Int) {
    IDLE("Ready", 0),
    CHECKING("Checking Schedule & Device", 1),
    ALERTING("Buzzer Alerting Patient", 2),
    SELECTING_COMPARTMENT("Servo 1 Positioning Tray", 3),
    OPENING_GATE("Servo 2 Opening Dispenser Gate", 4),
    WAITING_FOR_IR("Medicine Dropping - Sensor Waiting", 5),
    MEDICINE_DETECTED("IR Beam Confirmed Pill Drop", 6),
    CLOSING_GATE("Servo 2 Closing Gate", 7),
    COMPLETED("Dispense Completed Successfully", 8),
    TIMEOUT("IR Sensor Timeout (Medicine Not Detected)", 9),
    FAILED("Dispensing Operation Failed", 10),
    MISSED("Dose Missed by Patient", 11)
}

data class HardwareStatus(
    val isOnline: Boolean = true,
    val esp32Ip: String = "192.168.4.1",
    val wifiStatus: String = "Connected (MedQ_IoT)",
    val rtcStatus: String = "Working (DS3231)",
    val oledStatus: String = "Working (SSD1306)",
    val irStatus: String = "Active (Beam Clear)",
    val servo1Status: String = "Ready (Tray Selector)",
    val servo2Status: String = "Ready (Gate Controller)",
    val buzzerStatus: String = "Standby",
    val firmwareVersion: String = "v1.2.0-esp32",
    val lastSeenTime: String = "Just now"
)

data class CompartmentInfo(
    val compartmentNumber: Int,
    val medicine: MedicineEntity?,
    val nextScheduleTime: String?,
    val status: String // "UPCOMING", "PENDING", "COMPLETED", "EMPTY"
)

data class AdherenceStats(
    val totalDoses: Int = 0,
    val completedDoses: Int = 0,
    val missedDoses: Int = 0,
    val failedDoses: Int = 0,
    val notDetectedDoses: Int = 0,
    val adherencePercentage: Int = 100
)
