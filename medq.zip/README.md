# MedQ – Smart Medicine Dispenser

An IoT-based automatic medicine dispensing ecosystem with real-time tracking, hardware diagnostics, and patient adherence management.

**Tagline:** *Smart Medicine Dispenser*

---

## 1. System Architecture

```
                    ┌───────────────────────────┐
                    │    MedQ Android App       │
                    │   (Jetpack Compose UI)    │
                    └─────────────┬─────────────┘
                                  │
                              HTTP / REST
                                  │
                    ┌─────────────▼─────────────┐
                    │   Node.js + Express API   │
                    │      (Prisma + PG)        │
                    └─────────────┬─────────────┘
                                  │
                          Device Commands
                                  │
                    ┌─────────────▼─────────────┐
                    │       ESP32 Micro         │
                    └─────────────┬─────────────┘
                                  │
         ┌────────────┬───────────┼───────────┬────────────┐
         │            │           │           │            │
      DS3231       OLED       Servo 1     Servo 2      Buzzer
      (RTC)      (SSD1306)    (Tray)      (Gate)       (Piezo)
                                  │
                              IR Sensor
                              (Pill Drop)
```

---

## 2. Key Capabilities

### 📱 Android Application (`app/`)
- **Material Design 3 Medical Interface**: Clean, accessible palette with high contrast, haptic feedback, and responsive layout.
- **Home Dashboard**: Real-time clock, adherence metrics (Completed, Pending, Missed, Adherence Score %), Next Medicine countdown, and 4 Compartment status cards.
- **Medicine & Multi-Schedule Management**: Add, edit, delete, and enable/disable medicines across bays 1 to 4 with multiple reminder alarms per day.
- **Automatic & Manual Dispensing State Machine**: Full 10-state visual modal:
  `IDLE` → `CHECKING` → `ALERTING` → `SELECTING_COMPARTMENT` → `OPENING_GATE` → `WAITING_FOR_IR` → `MEDICINE_DETECTED` → `CLOSING_GATE` → `COMPLETED` (or `TIMEOUT` / `FAILED`).
- **Hardware Control & Diagnostics**:
  - Live status badges for ESP32, Wi-Fi, RTC, OLED, IR Sensor, Servo 1, Servo 2, Buzzer.
  - Manual actuation buttons (Test Servo 1 angles, Test Servo 2 open/close gate, Test Buzzer beep, Test IR sensor beam).
- **History & Analytics**:
  - Filter by Today, This Week, This Month, or All.
  - Search by medicine name.
  - Adherence gauge and weekly distribution charts.
- **Dual Operating Modes**:
  - **Demo Mode**: Full software simulation requiring zero physical hardware, perfect for demonstrations and offline presentations.
  - **Real Hardware Mode**: Real-time HTTP REST communication with the physical ESP32 and optical IR verification without false reporting.

### 🌐 Backend API (`backend/`)
- Node.js + Express REST API.
- PostgreSQL database with Prisma ORM.
- JWT authentication and bcrypt password hashing.
- Duplicate dose prevention / idempotency mechanism.
- Centralized error handling and schema validation.

### ⚡ ESP32 Firmware (`esp32/`)
- Arduino C++ with FreeRTOS and ESP32Servo.
- DS3231 RTC for standalone offline timekeeping.
- SSD1306 OLED display for status messages and patient guidance.
- 2 × SG90 servos for tray positioning and gate opening.
- IR obstacle sensor for drop confirmation.
- Active buzzer alert system.

---

## 3. Repository Structure

```
medq/
├── app/                          # Native Android Jetpack Compose Mobile App
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/example/
│   │   │   ├── MainActivity.kt
│   │   │   ├── data/
│   │   │   │   ├── local/        # Room Database & DAOs
│   │   │   │   ├── model/        # Entities & Enums
│   │   │   │   ├── remote/       # ESP32 REST Client
│   │   │   │   └── repository/   # Repository & Dispensing State Machine
│   │   │   └── ui/
│   │   │       ├── components/   # CompartmentCard, DispensingModal, TopBar
│   │   │       ├── screens/      # Splash, Auth, Home, Meds, Control, History, Analytics, Settings
│   │   │       ├── theme/        # Material 3 Colors, Shapes, Typography
│   │   │       └── viewmodel/    # StateFlow & UI business logic
│   │   └── res/                  # Drawables, mipmaps, strings
├── backend/                      # Node.js + Express API Backend
│   ├── prisma/
│   │   ├── schema.prisma         # PostgreSQL schema definition
│   │   └── seed.js               # Initial demonstration database seed
│   ├── src/
│   │   ├── controllers/          # Auth, Medicine, Schedule, Dispense, Device, Analytics
│   │   ├── middleware/           # Auth, Error handling, Validation
│   │   ├── routes/               # API routes
│   │   ├── app.js
│   │   └── server.js
│   ├── package.json
│   └── README.md
├── esp32/                        # ESP32 Arduino C++ Firmware
│   ├── include/
│   │   ├── config.h              # Hardware calibration angles & timeouts
│   │   └── pins.h                # GPIO pin allocations
│   ├── src/
│   │   └── main.cpp              # WebServer REST API & dispensing logic
│   ├── platformio.ini
│   └── README.md
└── README.md                     # Monorepo Documentation
```

---

## 4. Hardware Pin Mapping

| Peripheral | ESP32 Pin | Logic Level | Description |
|---|---|---|---|
| **OLED SSD1306 SDA** | GPIO 21 | 3.3V | I2C Data Line (0x3C) |
| **OLED SSD1306 SCL** | GPIO 22 | 3.3V | I2C Clock Line (0x3C) |
| **RTC DS3231 SDA** | GPIO 21 | 3.3V | Shared I2C Data (0x68) |
| **RTC DS3231 SCL** | GPIO 22 | 3.3V | Shared I2C Clock (0x68) |
| **Servo 1 (Tray)** | GPIO 18 | PWM (5V Ext) | Selects Compartments 1 to 4 |
| **Servo 2 (Gate)** | GPIO 19 | PWM (5V Ext) | Dispensing Trapdoor Gate (0°/90°) |
| **IR Drop Sensor** | GPIO 27 | Input (3.3V) | Optical Drop Confirmation Beam |
| **Buzzer** | GPIO 23 | Output (3.3V) | Alert Patient Chime |

> **Wiring Warning:** Use an external regulated 5V power supply for the SG90 servos with a 470µF filter capacitor. Tie the ESP32 GND and external power GND together.

---

## 5. Quick Start Guide

### 📱 Android Application
1. The Android app compiles cleanly in this environment.
2. Launch on an Android device or emulator (minSdk 24, targetSdk 36).
3. Tap **Quick Demo Patient Login** on the auth screen.
4. By default, **Demo Mode** is enabled, allowing complete end-to-end testing of 4-bay medicine dispensing without needing physical hardware.
5. In **Settings**, toggle off Demo Mode to enter **Real Hardware Mode** and point the app to your ESP32's IP address.

### 🌐 Backend Server Setup
```bash
cd backend
npm install
cp .env.example .env
npx prisma generate
npx prisma migrate dev --name init
npm run seed
npm run dev
```

### ⚡ ESP32 Firmware Setup
```bash
cd esp32
# Configure your local Wi-Fi SSID in include/config.h
# Flash firmware using PlatformIO:
pio run -t upload
```

---

## 6. Verification & Acceptance Criteria
- [x] **Authentication**: Sign in, registration, session management, profile update, password change.
- [x] **Medicines Management**: Full CRUD, 4-compartment validation, dosage, instructions, multi-schedules.
- [x] **Automatic Dispensing State Machine**: 10 distinct states visually rendered in real time.
- [x] **IR Sensor Drop Verification**: Verifies physical pill delivery with timeout handling.
- [x] **Dual Mode Execution**: Instant Demo Mode simulation + physical REST API mode.
- [x] **Diagnostics & Controls**: Individual servo, buzzer, and IR sensor test buttons.
- [x] **Analytics & Compliance**: Adherence percentages and weekly trend charts.
