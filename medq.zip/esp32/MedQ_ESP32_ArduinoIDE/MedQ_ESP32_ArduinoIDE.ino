/*
 ============================================================================
  MedQ - Smart Medicine Dispenser Firmware
  Configured for YOUR EXACT Hardware Wiring:
  
  | Component        | ESP32 Pin |
  | ---------------- | --------- |
  | DS3231 SDA       | GPIO 21   |
  | DS3231 SCL       | GPIO 22   |
  | OLED SDA         | GPIO 21   |
  | OLED SCL         | GPIO 22   |
  | Buzzer (+)       | GPIO 25   |  <-- Configured on Pin 25
  | Servo 1 Signal   | GPIO 18   |  <-- Compartment Carousel (0°-180°)
  | Servo 2 Signal   | GPIO 19   |  <-- Dispensing Trapdoor Gate (0°-90°)
  | IR Sensor OUT    | GPIO 27   |  <-- Drop Confirmation Beam
  
  Libraries required in Arduino IDE:
  1. ArduinoJson (by Benoît Blanchon)
  2. ESP32Servo (by Kevin Harrington)
  3. Adafruit SSD1306 (by Adafruit)
  4. Adafruit GFX Library (by Adafruit)
  5. RTClib (by Adafruit)
 ============================================================================
*/

#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <ESP32Servo.h>
#include <ArduinoJson.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <RTClib.h>

// ============================================================================
// 1. WI-FI CREDENTIALS (REPLACE WITH YOUR WI-FI OR PHONE HOTSPOT)
// ============================================================================
const char* WIFI_SSID     = "YOUR_WIFI_SSID";       // <--- Put your Wi-Fi name here
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";   // <--- Put your Wi-Fi password here

// Fallback Access Point (If Wi-Fi router is offline or for direct mobile connection)
const char* AP_SSID       = "MedQ-Dispenser-AP";
const char* AP_PASSWORD   = "medq1234";

// ============================================================================
// 2. PIN DEFINITIONS MATCHING YOUR EXACT WIRING
// ============================================================================
#define I2C_SDA_PIN          21    // DS3231 SDA & OLED SDA
#define I2C_SCL_PIN          22    // DS3231 SCL & OLED SCL

#define SERVO1_TRAY_PIN      18    // Servo 1: Tray Carousel Selector
#define SERVO2_GATE_PIN      19    // Servo 2: Trapdoor Dispense Gate
#define BUZZER_PIN           25    // Buzzer Positive (+) on GPIO 25
#define IR_SENSOR_PIN        27    // IR Obstacle / Drop Sensor OUT
#define STATUS_LED_PIN       2     // Onboard Status LED

// ============================================================================
// 3. CALIBRATED ANGLES & TIMINGS
// ============================================================================
// Servo 1: 4 Compartment Bay Angles (0° - 180°)
const int COMPARTMENT_1_ANGLE = 0;
const int COMPARTMENT_2_ANGLE = 60;
const int COMPARTMENT_3_ANGLE = 120;
const int COMPARTMENT_4_ANGLE = 180;

// Servo 2: Gate Positions
const int GATE_CLOSED_ANGLE   = 0;     // Secure closed position
const int GATE_OPEN_ANGLE     = 90;    // Open release aperture

// IR Sensor polarity (Standard IR modules output LOW when beam is broken)
#define IR_DETECTED_LEVEL     LOW

const unsigned long IR_TIMEOUT_MS = 6000;
const int SERVO_SETTLE_MS         = 700;

// ============================================================================
// 4. OBJECTS & STATE
// ============================================================================
Adafruit_SSD1306 display(128, 64, &Wire, -1);
RTC_DS3231 rtc;
Servo servoTray;
Servo servoGate;
WebServer server(80);

bool rtcDetected   = false;
bool oledDetected  = false;
String currentStatus = "Ready";
unsigned long lastDisplayRefresh = 0;

// ============================================================================
// 5. HELPER FUNCTIONS
// ============================================================================

void beep(int durationMs = 200) {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(durationMs);
  digitalWrite(BUZZER_PIN, LOW);
}

int getAngleForCompartment(int comp) {
  switch (comp) {
    case 1: return COMPARTMENT_1_ANGLE;
    case 2: return COMPARTMENT_2_ANGLE;
    case 3: return COMPARTMENT_3_ANGLE;
    case 4: return COMPARTMENT_4_ANGLE;
    default: return COMPARTMENT_1_ANGLE;
  }
}

void setCorsHeaders() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
}

void updateOled(String statusText = "") {
  if (!oledDetected) return;

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  // Header
  display.setCursor(0, 0);
  display.println("MedQ Smart Dispenser");
  display.drawLine(0, 9, 128, 9, SSD1306_WHITE);

  // RTC Time from DS3231
  display.setCursor(0, 13);
  if (rtcDetected) {
    DateTime now = rtc.now();
    char timeStr[20];
    snprintf(timeStr, sizeof(timeStr), "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
    display.print("RTC Time: ");
    display.println(timeStr);
  } else {
    display.println("RTC: Offline");
  }

  // Local IP for connecting to MedQ App
  display.setCursor(0, 24);
  display.print("IP: ");
  if (WiFi.status() == WL_CONNECTED) {
    display.println(WiFi.localIP());
  } else {
    display.println(WiFi.softAPIP());
  }

  // IR Sensor Beam Status
  display.setCursor(0, 35);
  display.print("IR Beam: ");
  display.println((digitalRead(IR_SENSOR_PIN) == IR_DETECTED_LEVEL) ? "DETECTED" : "CLEAR");

  // Status Action Line
  display.drawLine(0, 46, 128, 46, SSD1306_WHITE);
  display.setCursor(0, 52);
  if (statusText.length() > 0) {
    display.println(statusText);
  } else {
    display.println("Status: " + currentStatus);
  }

  display.display();
}

// ============================================================================
// 6. DISPENSING CYCLE
// ============================================================================
bool executeDispense(int compartment, String medicine, String dosage) {
  Serial.println("\n--------------------------------------------------");
  Serial.printf("[MedQ Dispense] Bay %d: %s (%s)\n", compartment, medicine.c_str(), dosage.c_str());
  Serial.println("--------------------------------------------------");

  // Step 1: Chime buzzer on GPIO 25 to alert patient
  updateOled("Alerting Patient...");
  beep(1000);

  // Step 2: Rotate Servo 1 (Tray Carousel) to Bay angle
  updateOled("Positioning Bay " + String(compartment) + "...");
  int targetAngle = getAngleForCompartment(compartment);
  servoTray.write(targetAngle);
  delay(SERVO_SETTLE_MS);

  // Step 3: Open Servo 2 (Trapdoor Gate)
  updateOled("Opening Gate...");
  servoGate.write(GATE_OPEN_ANGLE);
  delay(300);

  // Step 4: Await Pill Drop confirmation via IR sensor (GPIO 27)
  updateOled("Awaiting IR Drop...");
  unsigned long startTime = millis();
  bool pillDetected = false;

  while (millis() - startTime < IR_TIMEOUT_MS) {
    if (digitalRead(IR_SENSOR_PIN) == IR_DETECTED_LEVEL) {
      pillDetected = true;
      Serial.println("[MedQ IR] Pill drop successfully detected!");
      break;
    }
    delay(20);
  }

  // Step 5: Close Servo 2 (Trapdoor Gate)
  updateOled("Closing Gate...");
  servoGate.write(GATE_CLOSED_ANGLE);
  delay(SERVO_SETTLE_MS);

  // Step 6: Confirmation
  if (pillDetected) {
    currentStatus = "Dispensed OK";
    updateOled("DISPENSED OK!");
    beep(120);
    delay(80);
    beep(120);
    return true;
  } else {
    currentStatus = "IR Timeout";
    updateOled("IR NOT DETECTED");
    return false;
  }
}

// ============================================================================
// 7. REST API ROUTES FOR MEDQ ANDROID APP
// ============================================================================
void setupRestApi() {

  // GET /api/status - Hardware diagnostic query
  server.on("/api/status", HTTP_GET, []() {
    setCorsHeaders();
    StaticJsonDocument<512> doc;
    doc["status"] = "online";
    doc["device"] = "MedQ Dispenser";
    doc["id"] = "MEDQ-ESP32-001";
    doc["ip"] = WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : WiFi.softAPIP().toString();
    doc["wifi"] = WiFi.status() == WL_CONNECTED ? "Connected" : "AP Mode";
    doc["rtc"] = rtcDetected ? "OK (DS3231 GPIO 21/22)" : "Offline";
    doc["oled"] = oledDetected ? "OK (SSD1306 GPIO 21/22)" : "Offline";
    doc["ir"] = (digitalRead(IR_SENSOR_PIN) == IR_DETECTED_LEVEL) ? "Pill Detected (GPIO 27)" : "Beam Clear (GPIO 27)";
    doc["servo1"] = "Ready (GPIO 18)";
    doc["servo2"] = "Ready (GPIO 19)";
    doc["buzzer"] = "Ready (GPIO 25)";
    doc["uptime"] = millis() / 1000;

    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
  });

  // GET /api/time - DS3231 RTC module reading
  server.on("/api/time", HTTP_GET, []() {
    setCorsHeaders();
    StaticJsonDocument<256> doc;
    if (rtcDetected) {
      DateTime now = rtc.now();
      char timeBuf[20];
      snprintf(timeBuf, sizeof(timeBuf), "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
      doc["timeString"] = timeBuf;
      doc["hour"] = now.hour();
      doc["minute"] = now.minute();
      doc["second"] = now.second();
    } else {
      doc["error"] = "RTC Offline";
    }
    String res;
    serializeJson(doc, res);
    server.send(200, "application/json", res);
  });

  // GET /api/ir - Live IR beam state
  server.on("/api/ir", HTTP_GET, []() {
    setCorsHeaders();
    int raw = digitalRead(IR_SENSOR_PIN);
    bool detected = (raw == IR_DETECTED_LEVEL);
    StaticJsonDocument<128> doc;
    doc["detected"] = detected;
    doc["raw"] = raw;
    String res;
    serializeJson(doc, res);
    server.send(200, "application/json", res);
  });

  // POST /api/dispense - Full dispense cycle
  server.on("/api/dispense", HTTP_POST, []() {
    setCorsHeaders();
    if (!server.hasArg("plain")) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Missing body\"}");
      return;
    }

    StaticJsonDocument<256> doc;
    DeserializationError error = deserializeJson(doc, server.arg("plain"));
    if (error) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"JSON error\"}");
      return;
    }

    int comp = doc["compartment"] | 1;
    String med = doc["medicine"] | "Medicine";
    String dosage = doc["dosage"] | "1 dose";

    bool success = executeDispense(comp, med, dosage);

    StaticJsonDocument<256> res;
    res["success"] = success;
    res["detected"] = success;
    res["compartment"] = comp;
    res["message"] = success ? "Medicine dispensed and verified by IR sensor."
                             : "IR Sensor Timeout: Pill not detected.";

    String output;
    serializeJson(res, output);
    server.send(200, "application/json", output);
  });

  // POST /api/servo - Manual test controls
  server.on("/api/servo", HTTP_POST, []() {
    setCorsHeaders();
    if (!server.hasArg("plain")) {
      server.send(400, "application/json", "{\"success\":false}");
      return;
    }
    StaticJsonDocument<256> doc;
    deserializeJson(doc, server.arg("plain"));

    int servoNum = doc["servo"] | 1;
    String action = doc["action"] | "select";

    if (servoNum == 1) {
      int comp = doc["compartment"] | 1;
      int angle = getAngleForCompartment(comp);
      servoTray.write(angle);
      server.send(200, "application/json", "{\"success\":true,\"message\":\"Servo 1 rotated\"}");
    } else {
      if (action == "open") {
        servoGate.write(GATE_OPEN_ANGLE);
      } else {
        servoGate.write(GATE_CLOSED_ANGLE);
      }
      server.send(200, "application/json", "{\"success\":true,\"message\":\"Servo 2 actuated\"}");
    }
  });

  // POST /api/buzzer - Manual buzzer test on GPIO 25
  server.on("/api/buzzer", HTTP_POST, []() {
    setCorsHeaders();
    StaticJsonDocument<128> doc;
    if (server.hasArg("plain")) {
      deserializeJson(doc, server.arg("plain"));
    }
    int duration = doc["durationMs"] | 1000;
    beep(duration);
    server.send(200, "application/json", "{\"success\":true}");
  });

  // Handle CORS pre-flight OPTIONS
  server.onNotFound([]() {
    if (server.method() == HTTP_OPTIONS) {
      setCorsHeaders();
      server.send(204);
    } else {
      server.send(404, "text/plain", "Not Found");
    }
  });
}

// ============================================================================
// 8. SETUP & LOOP
// ============================================================================
void setup() {
  Serial.begin(115200);
  delay(800);
  Serial.println("\n==========================================");
  Serial.println(" MedQ Dispenser - Initializing Hardware");
  Serial.println("==========================================");

  // 1. Initialize Buzzer on GPIO 25
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  // 2. Initialize Status LED
  pinMode(STATUS_LED_PIN, OUTPUT);
  digitalWrite(STATUS_LED_PIN, HIGH);

  // 3. Initialize IR Sensor on GPIO 27
  pinMode(IR_SENSOR_PIN, INPUT_PULLUP);

  // 4. Initialize Shared I2C Bus (SDA = 21, SCL = 22)
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);

  // 5. Initialize SSD1306 OLED (0x3C)
  if (display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    oledDetected = true;
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(10, 15);
    display.println("MedQ Dispenser");
    display.setCursor(10, 32);
    display.println("Connecting Wi-Fi...");
    display.display();
    Serial.println("[OK] SSD1306 OLED detected on I2C (GPIO 21/22)");
  } else {
    Serial.println("[WARNING] SSD1306 OLED not found at 0x3C");
  }

  // 6. Initialize DS3231 RTC (0x68)
  if (rtc.begin()) {
    rtcDetected = true;
    if (rtc.lostPower()) {
      Serial.println("[OK] RTC lost power, setting compile time");
      rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
    }
    Serial.println("[OK] DS3231 RTC detected on I2C (GPIO 21/22)");
  } else {
    Serial.println("[WARNING] DS3231 RTC not found at 0x68");
  }

  // 7. Initialize Servos with ESP32 PWM
  ESP32PWM::allocateTimer(0);
  ESP32PWM::allocateTimer(1);
  servoTray.setPeriodHertz(50);
  servoGate.setPeriodHertz(50);

  servoTray.attach(SERVO1_TRAY_PIN, 500, 2400); // GPIO 18
  servoGate.attach(SERVO2_GATE_PIN, 500, 2400); // GPIO 19

  servoTray.write(COMPARTMENT_1_ANGLE);
  servoGate.write(GATE_CLOSED_ANGLE);
  Serial.println("[OK] Servo 1 (GPIO 18) and Servo 2 (GPIO 19) calibrated");

  // 8. Connect to Wi-Fi
  Serial.printf("[MedQ] Connecting to Wi-Fi: %s\n", WIFI_SSID);
  WiFi.mode(WIFI_AP_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n[OK] Connected to Wi-Fi!");
    Serial.print("[OK] >>> ESP32 IP ADDRESS: ");
    Serial.println(WiFi.localIP());
    Serial.println("[OK] Enter this IP in the MedQ Android App under Settings!");
  } else {
    Serial.println("\n[INFO] Wi-Fi connection failed. Starting Direct AP Mode...");
    WiFi.softAP(AP_SSID, AP_PASSWORD);
    Serial.print("[INFO] Connect phone to Wi-Fi: ");
    Serial.println(AP_SSID);
    Serial.print("[INFO] ESP32 AP IP: ");
    Serial.println(WiFi.softAPIP());
  }

  // 9. Start Web Server
  setupRestApi();
  server.begin();
  Serial.println("[OK] HTTP REST Server listening on Port 80");

  // Startup Chime on GPIO 25
  beep(150);
  delay(100);
  beep(150);

  updateOled("MedQ Ready");
}

void loop() {
  server.handleClient();

  // Refresh OLED Display every 1 second
  if (millis() - lastDisplayRefresh >= 1000) {
    lastDisplayRefresh = millis();
    updateOled();
  }
}
