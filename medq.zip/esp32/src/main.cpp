#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <ESP32Servo.h>
#include <ArduinoJson.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <RTClib.h>

#include "pins.h"
#include "config.h"

// Hardware Instances
Adafruit_SSD1306 display(128, 64, &Wire, -1);
RTC_DS3231 rtc;
Servo servoTray;
Servo servoGate;
WebServer server(HTTP_SERVER_PORT);

// Global State
bool rtcFound = false;
bool oledFound = false;
String lastDispenseResult = "Ready";
String nextMedicineName = "Paracetamol 500mg";
String nextMedicineTime = "08:00 AM";
unsigned long lastDisplayUpdate = 0;

// Function Prototypes
void setupHardware();
void setupWiFi();
void setupApiRoutes();
void updateOledDisplay(String statusOverride = "");
bool executeDispensingWorkflow(int compartment, String medicineName, String dosage);
void playBuzzerAlert(int durationMs = BUZZER_ALERT_DURATION_MS);
int getCompartmentAngle(int compartment);

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("\n==========================================");
  Serial.println(" MedQ - Smart Medicine Dispenser Firmware");
  Serial.println("==========================================");

  setupHardware();
  setupWiFi();
  setupApiRoutes();

  server.begin();
  Serial.println("[MedQ] HTTP REST API Server listening on port 80");
  updateOledDisplay("MedQ Ready");
}

void loop() {
  server.handleClient();

  // Periodic OLED display refresh for clock & status
  if (millis() - lastDisplayUpdate >= OLED_REFRESH_INTERVAL_MS) {
    lastDisplayUpdate = millis();
    updateOledDisplay();
  }
}

void setupHardware() {
  // Pin modes
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  pinMode(STATUS_LED_PIN, OUTPUT);
  digitalWrite(STATUS_LED_PIN, HIGH);

  pinMode(IR_SENSOR_PIN, INPUT_PULLUP);

  // Initialize I2C Bus
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);

  // Initialize SSD1306 OLED Display (Address 0x3C)
  if (display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    oledFound = true;
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(10, 10);
    display.println("MedQ Dispenser");
    display.setCursor(10, 26);
    display.println("Initializing...");
    display.display();
    Serial.println("[MedQ] OLED Display SSD1306 initialized.");
  } else {
    Serial.println("[MedQ] Warning: SSD1306 OLED Display not detected at 0x3C");
  }

  // Initialize DS3231 RTC (Address 0x68)
  if (rtc.begin()) {
    rtcFound = true;
    if (rtc.lostPower()) {
      Serial.println("[MedQ] RTC lost power, setting compile time...");
      rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
    }
    Serial.println("[MedQ] DS3231 RTC Module initialized.");
  } else {
    Serial.println("[MedQ] Warning: DS3231 RTC Module not detected.");
  }

  // Initialize SG90 Servos
  ESP32PWM::allocateTimer(0);
  ESP32PWM::allocateTimer(1);
  servoTray.setPeriodHertz(50);
  servoGate.setPeriodHertz(50);

  servoTray.attach(SERVO1_TRAY_PIN, 500, 2400);
  servoGate.attach(SERVO2_GATE_PIN, 500, 2400);

  // Set default initial resting angles
  servoTray.write(SERVO1_COMPARTMENT_1_ANGLE);
  servoGate.write(SERVO2_GATE_CLOSED_ANGLE);
  Serial.println("[MedQ] Servo 1 (Tray) and Servo 2 (Gate) calibrated.");

  // Startup Chime
  playBuzzerAlert(200);
}

void setupWiFi() {
  Serial.print("[MedQ] Connecting to Wi-Fi: ");
  Serial.println(WIFI_SSID);

  WiFi.mode(WIFI_AP_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 15) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n[MedQ] Wi-Fi Connected!");
    Serial.print("[MedQ] IP Address: ");
    Serial.println(WiFi.localIP());
  } else {
    // Fallback to standalone Access Point for local field control
    Serial.println("\n[MedQ] Wi-Fi STA failed. Starting AP Mode: MedQ-Dispenser-AP");
    WiFi.softAP("MedQ-Dispenser-AP", "medq1234");
    Serial.print("[MedQ] AP IP Address: ");
    Serial.println(WiFi.softAPIP());
  }
}

void setupApiRoutes() {
  // CORS Headers Helper
  auto sendCors = []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.sendHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
    server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
  };

  server.on("/api/status", HTTP_GET, [&]() {
    sendCors();
    StaticJsonDocument<512> doc;
    doc["status"] = "online";
    doc["device"] = DEVICE_NAME;
    doc["id"] = DEVICE_ID;
    doc["ip"] = WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : WiFi.softAPIP().toString();
    doc["wifi"] = WiFi.status() == WL_CONNECTED ? "Connected" : "AP Mode";
    doc["firmware"] = FIRMWARE_VERSION;
    doc["uptime"] = millis() / 1000;
    doc["rtc"] = rtcFound ? "OK (DS3231)" : "Hardware Error";
    doc["oled"] = oledFound ? "OK (SSD1306)" : "Hardware Error";
    doc["ir"] = (digitalRead(IR_SENSOR_PIN) == IR_DETECTION_LOGIC_LEVEL) ? "Pill Detected" : "Beam Clear";
    doc["servo1"] = "Calibrated (Tray)";
    doc["servo2"] = "Calibrated (Gate)";
    doc["buzzer"] = "Standby";

    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
  });

  server.on("/api/time", HTTP_GET, [&]() {
    sendCors();
    StaticJsonDocument<256> doc;
    if (rtcFound) {
      DateTime now = rtc.now();
      doc["hour"] = now.hour();
      doc["minute"] = now.minute();
      doc["second"] = now.second();
      doc["year"] = now.year();
      doc["month"] = now.month();
      doc["day"] = now.day();
      char timeBuf[20];
      snprintf(timeBuf, sizeof(timeBuf), "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
      doc["timeString"] = timeBuf;
    } else {
      doc["error"] = "RTC hardware offline";
    }
    String res;
    serializeJson(doc, res);
    server.send(200, "application/json", res);
  });

  server.on("/api/ir", HTTP_GET, [&]() {
    sendCors();
    int raw = digitalRead(IR_SENSOR_PIN);
    bool detected = (raw == IR_DETECTION_LOGIC_LEVEL);
    StaticJsonDocument<128> doc;
    doc["detected"] = detected;
    doc["raw"] = raw;
    String res;
    serializeJson(doc, res);
    server.send(200, "application/json", res);
  });

  server.on("/api/dispense", HTTP_POST, [&]() {
    sendCors();
    if (!server.hasArg("plain")) {
      server.send(400, "application/json", "{\"success\":false,\"message\":\"Missing body\"}");
      return;
    }
    StaticJsonDocument<256> doc;
    deserializeJson(doc, server.arg("plain"));

    int compartment = doc["compartment"] | 1;
    String medicine = doc["medicine"] | "Medicine";
    String dosage = doc["dosage"] | "1 dose";

    bool success = executeDispensingWorkflow(compartment, medicine, dosage);

    StaticJsonDocument<256> resDoc;
    resDoc["success"] = success;
    resDoc["detected"] = success;
    resDoc["message"] = success ? "Medicine successfully dispensed and verified by IR sensor."
                                : "IR Sensor Timeout: Medicine was not detected falling into tray.";
    resDoc["compartment"] = compartment;
    resDoc["timestamp"] = millis();

    String out;
    serializeJson(resDoc, out);
    server.send(200, "application/json", out);
  });

  server.on("/api/servo", HTTP_POST, [&]() {
    sendCors();
    StaticJsonDocument<256> doc;
    deserializeJson(doc, server.arg("plain"));
    int servoNum = doc["servo"] | 1;
    String action = doc["action"] | "select";

    if (servoNum == 1) {
      int comp = doc["compartment"] | 1;
      int angle = getCompartmentAngle(comp);
      servoTray.write(angle);
      server.send(200, "application/json", "{\"success\":true,\"message\":\"Servo 1 positioned\"}");
    } else {
      if (action == "open") {
        servoGate.write(SERVO2_GATE_OPEN_ANGLE);
      } else {
        servoGate.write(SERVO2_GATE_CLOSED_ANGLE);
      }
      server.send(200, "application/json", "{\"success\":true,\"message\":\"Servo 2 gate actuated\"}");
    }
  });

  server.on("/api/buzzer", HTTP_POST, [&]() {
    sendCors();
    StaticJsonDocument<128> doc;
    deserializeJson(doc, server.arg("plain"));
    bool enabled = doc["enabled"] | true;
    int duration = doc["durationMs"] | 1000;
    if (enabled) playBuzzerAlert(duration);
    server.send(200, "application/json", "{\"success\":true}");
  });

  // Handle pre-flight CORS requests
  server.onNotFound([&]() {
    if (server.method() == HTTP_OPTIONS) {
      sendCors();
      server.send(204);
    } else {
      server.send(404, "text/plain", "Not Found");
    }
  });
}

int getCompartmentAngle(int compartment) {
  switch (compartment) {
    case 1: return SERVO1_COMPARTMENT_1_ANGLE;
    case 2: return SERVO1_COMPARTMENT_2_ANGLE;
    case 3: return SERVO1_COMPARTMENT_3_ANGLE;
    case 4: return SERVO1_COMPARTMENT_4_ANGLE;
    default: return SERVO1_COMPARTMENT_1_ANGLE;
  }
}

void playBuzzerAlert(int durationMs) {
  digitalWrite(BUZZER_PIN, HIGH);
  delay(durationMs);
  digitalWrite(BUZZER_PIN, LOW);
}

bool executeDispensingWorkflow(int compartment, String medicineName, String dosage) {
  Serial.println("\n-------------------------------------------");
  Serial.printf("[MedQ Dispenser] START Dispensing Compartment %d: %s (%s)\n", compartment, medicineName.c_str(), dosage.c_str());
  Serial.println("-------------------------------------------");

  // Step 1: Alerting Patient via Buzzer
  updateOledDisplay("ALERTING PATIENT");
  playBuzzerAlert(BUZZER_ALERT_DURATION_MS);

  // Step 2: Selecting Compartment (Servo 1)
  updateOledDisplay("SELECTING TRAY...");
  int targetAngle = getCompartmentAngle(compartment);
  servoTray.write(targetAngle);
  delay(SERVO_MOVE_SETTLE_MS);

  // Step 3: Opening Dispensing Gate (Servo 2)
  updateOledDisplay("OPENING GATE...");
  servoGate.write(SERVO2_GATE_OPEN_ANGLE);
  delay(300);

  // Step 4: Monitoring IR Drop Channel
  updateOledDisplay("WAITING FOR IR...");
  unsigned long startWait = millis();
  bool pillDetected = false;

  while (millis() - startWait < DISPENSE_IR_TIMEOUT_MS) {
    if (digitalRead(IR_SENSOR_PIN) == IR_DETECTION_LOGIC_LEVEL) {
      pillDetected = true;
      Serial.println("[MedQ IR] Medicine confirmed dropped!");
      break;
    }
    delay(20);
  }

  // Step 5: Close Gate (Servo 2)
  updateOledDisplay("CLOSING GATE...");
  servoGate.write(SERVO2_GATE_CLOSED_ANGLE);
  delay(SERVO_MOVE_SETTLE_MS);

  // Step 6: Report and Display Results
  if (pillDetected) {
    lastDispenseResult = "DISPENSED OK";
    updateOledDisplay("DISPENSED OK!");
    playBuzzerAlert(150);
    delay(100);
    playBuzzerAlert(150);
    Serial.println("[MedQ Dispenser] Dispensing sequence SUCCESSFUL.");
    return true;
  } else {
    lastDispenseResult = "NOT DETECTED";
    updateOledDisplay("NOT DETECTED!");
    Serial.println("[MedQ Dispenser] WARNING: Medicine was NOT detected by IR sensor.");
    return false;
  }
}

void updateOledDisplay(String statusOverride) {
  if (!oledFound) return;

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  // Header Title
  display.setCursor(0, 0);
  display.println("MedQ Smart Dispenser");
  display.drawLine(0, 10, 128, 10, SSD1306_WHITE);

  // Current RTC Time
  display.setCursor(0, 15);
  if (rtcFound) {
    DateTime now = rtc.now();
    char timeStr[20];
    snprintf(timeStr, sizeof(timeStr), "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
    display.print("Time: ");
    display.println(timeStr);
  } else {
    display.println("Time: Syncing...");
  }

  // Next Medicine
  display.setCursor(0, 27);
  display.println("Next Dose:");
  display.setCursor(0, 37);
  display.println(nextMedicineName);

  // Status / Dispense Message
  display.drawLine(0, 48, 128, 48, SSD1306_WHITE);
  display.setCursor(0, 52);
  if (statusOverride.length() > 0) {
    display.println(statusOverride);
  } else {
    display.println("Status: " + lastDispenseResult);
  }

  display.display();
}
