# MedQ ESP32 Firmware

The embedded C++ firmware for the **MedQ – Smart Medicine Dispenser** system using the Arduino framework on ESP32.

---

## 1. Hardware Bill of Materials
- **ESP32 DevKit V1** (30-pin or 38-pin)
- **DS3231 I2C High-Precision RTC Module**
- **0.96 inch I2C SSD1306 OLED Display (128x64)**
- **2 × SG90 Micro Servo Motors**
- **IR Obstacle / Proximity Sensor Module (TCRT5000 / LM393 comparator)**
- **Active 5V Buzzer**
- **External 5V Regulated Power Supply (min 2A)** for servos
- **470µF Electrolytic Capacitor** across 5V servo rail

---

## 2. Wiring & Pin Configuration

| Component | Pin Function | ESP32 Pin | Power Rail | Notes |
|---|---|---|---|---|
| **SSD1306 OLED** | SDA | **GPIO 21** | ESP32 3.3V / GND | Shared I2C Bus (Address 0x3C) |
| | SCL | **GPIO 22** | | |
| **DS3231 RTC** | SDA | **GPIO 21** | ESP32 3.3V / GND | Shared I2C Bus (Address 0x68) |
| | SCL | **GPIO 22** | | |
| **Servo 1 (Tray)** | Signal (PWM) | **GPIO 18** | **External 5V / Common GND** | 4-Compartment Carousel Angle |
| **Servo 2 (Gate)** | Signal (PWM) | **GPIO 19** | **External 5V / Common GND** | Dispenser Release Gate (0°-90°) |
| **IR Sensor** | OUT | **GPIO 27** | ESP32 3.3V / GND | Drop Detection Aperture Beam |
| **Buzzer** | VCC / Signal | **GPIO 25** | ESP32 3.3V / GND | Alert Chime for Patient |

> ⚠️ **CRITICAL POWER INSTRUCTION:**
> Do **NOT** power the two SG90 servos from the ESP32's 3.3V or VIN pin directly. When the servos actuate simultaneously, the surge in current can cause an ESP32 brownout reset. Use an external regulated 5V (2A) power supply with a **470µF capacitor** connected between +5V and GND. **Ensure the external power supply GND and the ESP32 GND are joined together.**

---

## 3. Hardware Calibration (`include/config.h`)

You can calibrate your physical 3D-printed carousel and trapdoor without modifying the core logic:

```cpp
// Tray Carousel Angles:
#define SERVO1_COMPARTMENT_1_ANGLE   0
#define SERVO1_COMPARTMENT_2_ANGLE   60
#define SERVO1_COMPARTMENT_3_ANGLE   120
#define SERVO1_COMPARTMENT_4_ANGLE   180

// Gate Angles:
#define SERVO2_GATE_CLOSED_ANGLE     0
#define SERVO2_GATE_OPEN_ANGLE       90

// IR Sensor Optical Polarity:
#define IR_DETECTION_LOGIC_LEVEL     LOW // or HIGH depending on sensor model
```

---

## 4. REST API Endpoints on ESP32

The ESP32 exposes the following endpoints on port 80:

- `GET /api/status` - Complete hardware and subsystem status (RTC, OLED, IR, Servos, Wi-Fi).
- `GET /api/time` - Current time read from the DS3231 RTC module.
- `GET /api/ir` - Live IR sensor beam status.
- `POST /api/dispense` - Trigger physical dispensing:
  ```json
  {
    "compartment": 1,
    "medicine": "Paracetamol",
    "dosage": "500 mg"
  }
  ```
- `POST /api/servo` - Test manual servo movement:
  ```json
  {
    "servo": 1,
    "action": "select",
    "compartment": 2
  }
  ```
- `POST /api/buzzer` - Test buzzer chime:
  ```json
  {
    "enabled": true,
    "durationMs": 1200
  }
  ```

---

## 5. Uploading Firmware

### Option A: Using PlatformIO (Recommended)
1. Open this `esp32` folder in VS Code with the PlatformIO extension.
2. Connect your ESP32 via USB.
3. Click **Upload** or run `pio run -t upload`.
4. Monitor output with `pio device monitor -b 115200`.

### Option B: Using Arduino IDE
1. Install the **ESP32 by Espressif Systems** board package.
2. Install required libraries:
   - `ArduinoJson` (v6.x)
   - `ESP32Servo`
   - `Adafruit SSD1306` & `Adafruit GFX`
   - `RTClib`
3. Select board **ESP32 Dev Module**.
4. Click **Upload**.
