#ifndef MEDQ_CONFIG_H
#define MEDQ_CONFIG_H

#include <Arduino.h>

// ========================================================
// MedQ Hardware Configuration & Calibration
// ========================================================

// Network & Device Identity
#define WIFI_SSID             "MedQ_IoT_Network"
#define WIFI_PASSWORD         "MedQPass2026"
#define DEVICE_NAME           "MedQ-Dispenser-Alpha"
#define DEVICE_ID             "MEDQ-ESP32-001"
#define FIRMWARE_VERSION      "v1.2.0-esp32"
#define HTTP_SERVER_PORT      80

// Servo 1: Tray Carousel Angle Mapping (Degrees 0-180)
#define SERVO1_COMPARTMENT_1_ANGLE   0
#define SERVO1_COMPARTMENT_2_ANGLE   60
#define SERVO1_COMPARTMENT_3_ANGLE   120
#define SERVO1_COMPARTMENT_4_ANGLE   180

// Servo 2: Dispensing Gate Calibration (Degrees 0-180)
#define SERVO2_GATE_CLOSED_ANGLE     0
#define SERVO2_GATE_OPEN_ANGLE       90

// IR Sensor Optical Polarity
// Set to LOW if active-low (beam break pulls pin LOW), or HIGH if active-high
#define IR_DETECTION_LOGIC_LEVEL     LOW

// Timing Configurations (Milliseconds)
#define DISPENSE_IR_TIMEOUT_MS       6000    // Max wait for pill drop
#define BUZZER_ALERT_DURATION_MS     1200    // Pre-dispensing alert beep
#define SERVO_MOVE_SETTLE_MS         800     // Delay to let servo finish rotation
#define OLED_REFRESH_INTERVAL_MS     1000    // OLED screen clock update interval

#endif // MEDQ_CONFIG_H
