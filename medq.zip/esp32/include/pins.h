#ifndef MEDQ_PINS_H
#define MEDQ_PINS_H

// ========================================================
// MedQ ESP32 Pin Configuration
// ========================================================

// I2C Bus (Shared by DS3231 RTC and SSD1306 OLED)
#define I2C_SDA_PIN          21
#define I2C_SCL_PIN          22

// Actuators
#define SERVO1_TRAY_PIN      18    // Servo 1: 4-compartment tray selector
#define SERVO2_GATE_PIN      19    // Servo 2: Dispensing aperture trapdoor gate
#define BUZZER_PIN           25    // Piezo Buzzer on GPIO 25

// Sensors
#define IR_SENSOR_PIN        27    // IR optical obstacle sensor (drop detector)

// Status LED (Onboard)
#define STATUS_LED_PIN       2

#endif // MEDQ_PINS_H
